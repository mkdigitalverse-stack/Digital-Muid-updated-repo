var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_config = require("dotenv/config");
var import_express4 = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_vite = require("vite");

// server/razorpay.js
var import_razorpay = __toESM(require("razorpay"), 1);
var import_crypto = __toESM(require("crypto"), 1);
var razorpayInstance = null;
function getRazorpayKeyId() {
  return process.env.RAZORPAY_KEY_ID || process.env.VITE_RAZORPAY_KEY_ID || null;
}
function isRazorpayConfigured() {
  const keyId = process.env.RAZORPAY_KEY_ID;
  const keySecret = process.env.RAZORPAY_KEY_SECRET;
  return Boolean(keyId && keySecret);
}
function isWebhookConfigured() {
  return Boolean(process.env.RAZORPAY_WEBHOOK_SECRET);
}
function getRazorpayClient() {
  const key_id = process.env.RAZORPAY_KEY_ID;
  const key_secret = process.env.RAZORPAY_KEY_SECRET;
  if (!key_id || !key_secret) {
    return null;
  }
  if (!razorpayInstance) {
    razorpayInstance = new import_razorpay.default({
      key_id,
      key_secret
    });
  }
  return razorpayInstance;
}
function verifyWebhookSignature(rawBody, signature) {
  const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
  if (!secret || !signature || !rawBody) {
    return false;
  }
  try {
    const expectedSignature = import_crypto.default.createHmac("sha256", secret).update(rawBody).digest("hex");
    const sigBuffer = Buffer.from(signature, "utf8");
    const expBuffer = Buffer.from(expectedSignature, "utf8");
    if (sigBuffer.length !== expBuffer.length) {
      return false;
    }
    return import_crypto.default.timingSafeEqual(sigBuffer, expBuffer);
  } catch (err) {
    console.error("[Razorpay Security] Error verifying webhook signature:", err);
    return false;
  }
}
function verifyPaymentSignature(orderId, paymentId, signature) {
  const secret = process.env.RAZORPAY_KEY_SECRET;
  if (!secret || !orderId || !paymentId || !signature) {
    return false;
  }
  try {
    const payload = `${orderId}|${paymentId}`;
    const expectedSignature = import_crypto.default.createHmac("sha256", secret).update(payload).digest("hex");
    const sigBuffer = Buffer.from(signature, "utf8");
    const expBuffer = Buffer.from(expectedSignature, "utf8");
    if (sigBuffer.length !== expBuffer.length) {
      return false;
    }
    return import_crypto.default.timingSafeEqual(sigBuffer, expBuffer);
  } catch (err) {
    console.error("[Razorpay Security] Error verifying payment signature:", err);
    return false;
  }
}

// server/supabaseServer.js
var import_supabase_js = require("@supabase/supabase-js");
var UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
function isValidUUID(id) {
  return typeof id === "string" && UUID_REGEX.test(id.trim());
}
function sanitizeSupabaseUrl(rawUrl) {
  if (!rawUrl || typeof rawUrl !== "string") return null;
  let decoded = rawUrl;
  try {
    decoded = decodeURIComponent(rawUrl);
  } catch {
  }
  const match = decoded.match(/https?:\/\/[^\s\n\r"'\\]+/);
  if (match) {
    try {
      new URL(match[0]);
      return match[0];
    } catch {
      return null;
    }
  }
  return null;
}
function sanitizeSupabaseKey(rawKey) {
  if (!rawKey || typeof rawKey !== "string") return null;
  let decoded = rawKey;
  try {
    decoded = decodeURIComponent(rawKey);
  } catch {
  }
  const clean = decoded.replace(/\s+/g, "").trim();
  return clean.length > 20 ? clean : null;
}
var supabaseServerInstance = null;
function isSupabaseServerConfigured() {
  const url = sanitizeSupabaseUrl(process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL);
  const serviceRoleKey = sanitizeSupabaseKey(process.env.SUPABASE_SERVICE_ROLE_KEY);
  return Boolean(url && serviceRoleKey);
}
function getSupabaseServerClient() {
  const url = sanitizeSupabaseUrl(process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL);
  const serviceRoleKey = sanitizeSupabaseKey(process.env.SUPABASE_SERVICE_ROLE_KEY);
  if (!url || !serviceRoleKey) {
    return null;
  }
  if (!supabaseServerInstance) {
    supabaseServerInstance = (0, import_supabase_js.createClient)(url, serviceRoleKey, {
      auth: {
        persistSession: false,
        autoRefreshToken: false
      }
    });
  }
  return supabaseServerInstance;
}
async function verifySupabaseToken(token) {
  if (!token || typeof token !== "string") {
    return { user: null, error: new Error("Authentication token is missing") };
  }
  const cleanToken = token.replace(/^Bearer\s+/i, "").trim();
  if (!cleanToken) {
    return { user: null, error: new Error("Malformed Bearer token") };
  }
  const url = sanitizeSupabaseUrl(process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL);
  const key = sanitizeSupabaseKey(
    process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KEY
  );
  if (!url || !key) {
    return { user: null, error: new Error("Supabase is not configured on the server") };
  }
  try {
    const authClient = (0, import_supabase_js.createClient)(url, key, {
      auth: {
        persistSession: false,
        autoRefreshToken: false
      }
    });
    const { data, error } = await authClient.auth.getUser(cleanToken);
    if (error || !data?.user) {
      return { user: null, error: error || new Error("User session invalid or expired") };
    }
    return { user: data.user, error: null };
  } catch (err) {
    return { user: null, error: err };
  }
}
function checkIsAdmin(user) {
  if (!user) return false;
  const email = (user.email || "").toLowerCase().trim();
  const adminEmails = ["mkdigitalverse@gmail.com", "admin@digitalmuid.com"];
  if (adminEmails.includes(email)) return true;
  if (user.app_metadata?.role === "admin" || user.user_metadata?.role === "admin") return true;
  return false;
}
function getSupabaseDbClient(userToken = null) {
  const serviceClient = getSupabaseServerClient();
  if (serviceClient) {
    return serviceClient;
  }
  const url = sanitizeSupabaseUrl(process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL);
  const anonKey = sanitizeSupabaseKey(process.env.VITE_SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KEY);
  if (!url || !anonKey) {
    return null;
  }
  const cleanToken = userToken ? userToken.replace(/^Bearer\s+/i, "").trim() : null;
  const clientOptions = {
    auth: {
      persistSession: false,
      autoRefreshToken: false
    }
  };
  if (cleanToken) {
    clientOptions.global = {
      headers: {
        Authorization: `Bearer ${cleanToken}`
      }
    };
  }
  return (0, import_supabase_js.createClient)(url, anonKey, clientOptions);
}

// server/paymentFulfillment.js
function calculateAuthoritativeCoursePrice(course) {
  const basePrice = Number(course?.price) || 0;
  const offerPrice = course?.offer_price != null ? Number(course.offer_price) : null;
  const offerExpiresAt = course?.offer_expires_at ? new Date(course.offer_expires_at) : null;
  const isOfferValid = offerPrice != null && offerPrice > 0 && (!offerExpiresAt || offerExpiresAt.getTime() > Date.now());
  const effectivePrice = isOfferValid ? offerPrice : basePrice;
  const currency = (course?.currency || "INR").toUpperCase();
  return {
    effectivePrice,
    currency,
    isOfferValid
  };
}
async function fulfillCourseEnrollment({
  userId,
  courseId,
  amount,
  currency,
  orderId,
  paymentId
}) {
  try {
    if (!userId || !isValidUUID(userId)) {
      return {
        success: false,
        error: "A valid student userId (UUID) is required for fulfillment.",
        code: "INVALID_USER_ID"
      };
    }
    if (!courseId || !isValidUUID(courseId)) {
      return {
        success: false,
        error: "A valid courseId (UUID) is required for fulfillment.",
        code: "INVALID_COURSE_ID"
      };
    }
    if (!orderId || typeof orderId !== "string" || !orderId.trim()) {
      return {
        success: false,
        error: "A valid Razorpay orderId is required for fulfillment.",
        code: "INVALID_ORDER_ID"
      };
    }
    if (!paymentId || typeof paymentId !== "string" || !paymentId.trim()) {
      return {
        success: false,
        error: "A valid Razorpay paymentId is required for fulfillment.",
        code: "INVALID_PAYMENT_ID"
      };
    }
    if (typeof amount !== "number" || isNaN(amount) || amount <= 0) {
      return {
        success: false,
        error: "A valid positive numeric amount is required for fulfillment.",
        code: "INVALID_AMOUNT"
      };
    }
    if (!currency || typeof currency !== "string") {
      return {
        success: false,
        error: "A valid currency code is required for fulfillment.",
        code: "INVALID_CURRENCY"
      };
    }
    const supabaseServer = getSupabaseServerClient();
    if (!supabaseServer) {
      console.warn(
        "[Payment Fulfillment] SUPABASE_SERVICE_ROLE_KEY is not configured on the server. Database fulfillment requires server role credentials."
      );
      return {
        success: false,
        fulfilled: false,
        error: "Server-side Supabase Service Role key is not configured.",
        code: "SERVICE_KEY_MISSING"
      };
    }
    const { data, error } = await supabaseServer.rpc("fulfill_course_enrollment", {
      p_user_id: userId.trim(),
      p_course_id: courseId.trim(),
      p_amount: amount,
      p_currency: currency.trim().toUpperCase(),
      p_order_id: orderId.trim(),
      p_payment_id: paymentId.trim()
    });
    if (error) {
      console.error("[Payment Fulfillment] RPC fulfill_course_enrollment error:", error);
      if (error.code === "PGRST202" || error.message?.includes("function") || error.message?.includes("does not exist")) {
        return {
          success: false,
          fulfilled: false,
          error: "Fulfillment RPC function does not exist in database. Migration 20260921000001_atomic_course_payment_fulfillment.sql must be applied.",
          code: "MIGRATION_PENDING"
        };
      }
      return {
        success: false,
        fulfilled: false,
        error: error.message || "Database RPC execution failed.",
        code: error.code || "RPC_ERROR"
      };
    }
    if (!data || data.success !== true) {
      console.warn("[Payment Fulfillment] RPC returned non-success result:", data);
      return {
        success: false,
        fulfilled: false,
        error: data?.error || "Fulfillment could not be completed.",
        code: "FULFILLMENT_REJECTED"
      };
    }
    console.log(
      `[Payment Fulfillment] Success: payment_id=${data.payment_id}, enrollment_id=${data.enrollment_id}, user=${userId}, course=${courseId}, already_fulfilled=${data.already_fulfilled}`
    );
    return {
      success: true,
      fulfilled: true,
      already_fulfilled: Boolean(data.already_fulfilled),
      payment_id: data.payment_id,
      enrollment_id: data.enrollment_id,
      course_slug: data.course_slug,
      course_title: data.course_title,
      amount: data.amount,
      currency: data.currency,
      message: data.message
    };
  } catch (err) {
    console.error("[Payment Fulfillment] Unexpected error during fulfillment:", err);
    return {
      success: false,
      fulfilled: false,
      error: err?.message || "An unexpected error occurred during fulfillment.",
      code: "UNEXPECTED_ERROR"
    };
  }
}
async function fulfillConsultationPayment({
  userId,
  bookingDetails,
  orderId,
  paymentId
}) {
  try {
    const supabaseServer = getSupabaseServerClient();
    if (!supabaseServer) {
      return {
        success: false,
        fulfilled: false,
        error: "Server-side Supabase Service Role client is not configured.",
        code: "SERVICE_KEY_MISSING"
      };
    }
    const cleanPaymentId = String(paymentId || "").trim();
    const cleanOrderId = String(orderId || "").trim();
    const { data: existingPayment } = await supabaseServer.from("payments").select("*").eq("razorpay_payment_id", cleanPaymentId).maybeSingle();
    const { data: existingBooking } = await supabaseServer.from("bookings").select("*").or(`payment_id.eq.${cleanPaymentId},razorpay_order_id.eq.${cleanOrderId}`).maybeSingle();
    if (existingPayment || existingBooking) {
      console.log(`[Consultation Fulfillment] Payment ${cleanPaymentId} already processed. Returning existing record.`);
      return {
        success: true,
        fulfilled: true,
        already_fulfilled: true,
        booking: existingBooking || null,
        payment: existingPayment || null
      };
    }
    let { data: product } = await supabaseServer.from("consultation_products").select("*").eq("active", true).limit(1).maybeSingle();
    if (!product) {
      const { data: canonProduct } = await supabaseServer.from("consultation_products").select("*").eq("id", "31bbb9bf-ce10-4da4-a517-dfc673f9b875").maybeSingle();
      product = canonProduct;
    }
    const baseAmount = Number(product?.base_price) || 499;
    const gstRate = Number(product?.gst_rate) || 0.18;
    const gstAmount = Number((baseAmount * gstRate).toFixed(2));
    const totalAmount = Number((baseAmount + gstAmount).toFixed(2));
    const currency = (product?.currency || "INR").toUpperCase();
    const durationMinutes = Number(product?.duration_minutes) || 30;
    let resolvedUserId = isValidUUID(userId) ? userId : null;
    if (!resolvedUserId && bookingDetails?.customerEmail) {
      try {
        const { data: profile } = await supabaseServer.from("profiles").select("id").eq("email", bookingDetails.customerEmail.trim().toLowerCase()).maybeSingle();
        if (profile?.id && isValidUUID(profile.id)) {
          resolvedUserId = profile.id;
        }
      } catch {
      }
    }
    const bookingCode = `DM-${(/* @__PURE__ */ new Date()).getFullYear()}-${Math.floor(1e3 + Math.random() * 9e3)}`;
    const randomMeetHash = `${Math.random().toString(36).substring(2, 6)}-${Math.random().toString(36).substring(2, 6)}-${Math.random().toString(36).substring(2, 6)}`;
    const meetUrl = `https://meet.google.com/${randomMeetHash}`;
    const bookingPayload = {
      booking_code: bookingCode,
      customer_name: String(bookingDetails?.customerName || "").trim(),
      customer_email: String(bookingDetails?.customerEmail || "").trim(),
      customer_phone: String(bookingDetails?.customerPhone || "").trim(),
      business_name: String(bookingDetails?.businessName || "").trim(),
      primary_challenge: String(bookingDetails?.primaryChallenge || "").trim(),
      desired_outcome: String(bookingDetails?.desiredOutcome || "").trim(),
      website: bookingDetails?.website ? String(bookingDetails.website).trim() : null,
      linkedin: bookingDetails?.linkedin ? String(bookingDetails.linkedin).trim() : null,
      booking_date: bookingDetails?.date || "",
      booking_time: bookingDetails?.time || "",
      duration_minutes: durationMinutes,
      base_amount: baseAmount,
      gst_rate: gstRate,
      gst_amount: gstAmount,
      total_amount: totalAmount,
      currency,
      payment_id: cleanPaymentId,
      razorpay_order_id: cleanOrderId,
      payment_status: "paid",
      calendar_event_id: `cal_evt_${Date.now()}`,
      meet_url: meetUrl,
      status: "confirmed",
      user_id: resolvedUserId,
      notes: "Booked online with verified Razorpay payment.",
      created_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    const { data: newBooking, error: bookingError } = await supabaseServer.from("bookings").insert(bookingPayload).select().single();
    if (bookingError) {
      console.error("[Consultation Fulfillment] Error inserting booking:", bookingError);
      return {
        success: false,
        fulfilled: false,
        error: bookingError.message || "Failed to record consultation booking."
      };
    }
    let paymentRecord = null;
    if (resolvedUserId) {
      const paymentPayload = {
        user_id: resolvedUserId,
        item_type: "consultation",
        item_id: product?.id || "31bbb9bf-ce10-4da4-a517-dfc673f9b875",
        item_title: product?.name || "Business Growth & Scaling Consultation",
        amount: totalAmount,
        currency,
        razorpay_order_id: cleanOrderId,
        razorpay_payment_id: cleanPaymentId,
        status: "captured",
        created_at: (/* @__PURE__ */ new Date()).toISOString()
      };
      const { data: newPayment, error: paymentError } = await supabaseServer.from("payments").insert(paymentPayload).select().single();
      if (paymentError) {
        console.warn("[Consultation Fulfillment] Notice inserting payment ledger:", paymentError.message);
      } else {
        paymentRecord = newPayment;
      }
    }
    try {
      await supabaseServer.from("leads").insert({
        name: bookingPayload.customer_name,
        email: bookingPayload.customer_email,
        phone: bookingPayload.customer_phone,
        source: "Consultation Intake (Paid)",
        interest: "1-on-1 Business Growth Consultation",
        notes: `Booking Code: ${bookingCode}, Date: ${bookingPayload.booking_date} at ${bookingPayload.booking_time}. Challenge: ${bookingPayload.primary_challenge}`,
        status: "New",
        amount: totalAmount,
        created_at: (/* @__PURE__ */ new Date()).toISOString()
      });
    } catch (leadErr) {
      console.warn("[Consultation Fulfillment] CRM lead record notice:", leadErr?.message);
    }
    return {
      success: true,
      fulfilled: true,
      already_fulfilled: false,
      booking: newBooking,
      payment: paymentRecord
    };
  } catch (err) {
    console.error("[Consultation Fulfillment] Unexpected error:", err);
    return {
      success: false,
      fulfilled: false,
      error: err?.message || "An unexpected error occurred during consultation fulfillment."
    };
  }
}
async function fulfillResourcePurchase({
  userId,
  resourceId,
  amount,
  currency,
  orderId,
  paymentId,
  customerName,
  customerEmail,
  customerPhone,
  resourceTitle
}) {
  try {
    const supabaseServer = getSupabaseServerClient();
    const cleanPaymentId = String(paymentId || "").trim();
    const cleanOrderId = String(orderId || "").trim();
    const cleanResourceId = String(resourceId || "").trim();
    const numericAmount = Number(amount) || 0;
    const finalCurrency = (currency || "INR").toUpperCase();
    if (supabaseServer) {
      const { data: existingPurchase } = await supabaseServer.from("resource_purchases").select("*").eq("razorpay_payment_id", cleanPaymentId).maybeSingle();
      const { data: existingPayment } = await supabaseServer.from("payments").select("*").eq("razorpay_payment_id", cleanPaymentId).maybeSingle();
      if (existingPurchase || existingPayment) {
        console.log(`[Resource Fulfillment] Payment ${cleanPaymentId} already processed. Returning existing record.`);
        return {
          success: true,
          fulfilled: true,
          already_fulfilled: true,
          purchase: existingPurchase || null,
          payment: existingPayment || null
        };
      }
    }
    let resolvedUserId = isValidUUID(userId) ? userId : null;
    if (!resolvedUserId && customerEmail && supabaseServer) {
      try {
        const { data: usersData } = await supabaseServer.auth.admin.listUsers();
        const match = usersData?.users?.find(
          (u) => u.email?.toLowerCase() === customerEmail.trim().toLowerCase()
        );
        if (match?.id && isValidUUID(match.id)) {
          resolvedUserId = match.id;
        } else {
          const tempPassword = `DM_${Math.random().toString(36).slice(2, 10)}!${Date.now()}`;
          const { data: newUser, error: createErr } = await supabaseServer.auth.admin.createUser({
            email: customerEmail.trim().toLowerCase(),
            password: tempPassword,
            email_confirm: true,
            user_metadata: {
              full_name: customerName || "Student Member",
              phone: customerPhone || null
            }
          });
          if (!createErr && newUser?.user?.id) {
            resolvedUserId = newUser.user.id;
          } else {
            const { data: retryUsers } = await supabaseServer.auth.admin.listUsers();
            const retryMatch = retryUsers?.users?.find(
              (u) => u.email?.toLowerCase() === customerEmail.trim().toLowerCase()
            );
            if (retryMatch?.id && isValidUUID(retryMatch.id)) {
              resolvedUserId = retryMatch.id;
            }
          }
        }
      } catch (userErr) {
        console.warn("[Resource Fulfillment] Notice resolving student account:", userErr?.message);
      }
    }
    let purchaseRecord = null;
    if (supabaseServer && isValidUUID(cleanResourceId)) {
      const purchasePayload = {
        user_id: resolvedUserId || null,
        customer_email: customerEmail ? customerEmail.trim().toLowerCase() : null,
        customer_phone: customerPhone || null,
        resource_id: cleanResourceId,
        razorpay_order_id: cleanOrderId,
        razorpay_payment_id: cleanPaymentId,
        amount: numericAmount,
        currency: finalCurrency,
        status: "active",
        purchased_at: (/* @__PURE__ */ new Date()).toISOString()
      };
      try {
        const { data: newPurchase, error: purchaseError } = await supabaseServer.from("resource_purchases").upsert(purchasePayload, { onConflict: "razorpay_payment_id" }).select().maybeSingle();
        if (!purchaseError && newPurchase) {
          purchaseRecord = newPurchase;
        } else if (purchaseError && purchaseError.code !== "PGRST205") {
          console.warn("[Resource Fulfillment] Notice saving resource_purchases row:", purchaseError.message);
        }
      } catch (tableErr) {
        console.warn("[Resource Fulfillment] Notice table resource_purchases check:", tableErr?.message);
      }
    }
    let paymentRecord = null;
    if (supabaseServer && resolvedUserId) {
      const paymentPayload = {
        user_id: resolvedUserId,
        item_type: "resource",
        item_id: cleanResourceId,
        item_title: resourceTitle || "Digital Resource Toolkit",
        amount: numericAmount,
        currency: finalCurrency,
        razorpay_order_id: cleanOrderId,
        razorpay_payment_id: cleanPaymentId,
        status: "captured",
        created_at: (/* @__PURE__ */ new Date()).toISOString()
      };
      try {
        const { data: newPayment, error: paymentError } = await supabaseServer.from("payments").insert(paymentPayload).select().maybeSingle();
        if (!paymentError && newPayment) {
          paymentRecord = newPayment;
        } else if (paymentError) {
          console.warn("[Resource Fulfillment] Notice inserting payment ledger:", paymentError.message);
        }
      } catch (pErr) {
        console.warn("[Resource Fulfillment] Payments insert error:", pErr?.message);
      }
    }
    if (supabaseServer && (customerEmail || customerName)) {
      try {
        await supabaseServer.from("crm_leads").insert({
          name: customerName || "Resource Buyer",
          email: customerEmail || "",
          phone: customerPhone || null,
          source: "Resource Purchase (Paid)",
          interest: resourceTitle ? `Purchased: ${resourceTitle}` : `Resource ID: ${cleanResourceId}`,
          notes: `Paid \u20B9${numericAmount}. Order: ${cleanOrderId}, Payment: ${cleanPaymentId}`,
          status: "Converted",
          amount: numericAmount,
          created_at: (/* @__PURE__ */ new Date()).toISOString()
        });
      } catch (leadErr) {
        console.warn("[Resource Fulfillment] CRM lead record notice:", leadErr?.message);
      }
    }
    if (!paymentRecord && !purchaseRecord) {
      console.error("[Resource Fulfillment] Database transaction failed: Neither payments nor resource_purchases was persisted.");
      return {
        success: false,
        fulfilled: false,
        error: "Failed to persist purchase record to database ledger. Please retry payment verification.",
        code: "DATABASE_WRITE_FAILED"
      };
    }
    return {
      success: true,
      fulfilled: true,
      already_fulfilled: false,
      purchase: purchaseRecord || {
        id: `res_pur_${Date.now()}`,
        userId: resolvedUserId || "guest",
        resourceId: cleanResourceId,
        razorpayOrderId: cleanOrderId,
        razorpayPaymentId: cleanPaymentId,
        amount: numericAmount,
        currency: finalCurrency,
        status: "active",
        purchasedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      payment: paymentRecord,
      resourceId: cleanResourceId,
      orderId: cleanOrderId,
      paymentId: cleanPaymentId,
      resolvedUserId
    };
  } catch (err) {
    console.error("[Resource Fulfillment] Unexpected error:", err);
    return {
      success: false,
      fulfilled: false,
      error: err?.message || "An unexpected error occurred during resource fulfillment."
    };
  }
}

// server/paymentWebhook.js
async function handleRazorpayWebhook(req, res) {
  try {
    const signature = req.headers["x-razorpay-signature"];
    if (!signature) {
      console.warn("[Razorpay Webhook] Missing X-Razorpay-Signature header.");
      return res.status(400).json({
        success: false,
        error: "Missing webhook signature header."
      });
    }
    if (!isWebhookConfigured()) {
      console.warn("[Razorpay Webhook] RAZORPAY_WEBHOOK_SECRET is not configured on the server.");
      return res.status(503).json({
        success: false,
        error: "Webhook verification secret is not configured on server."
      });
    }
    let rawBody;
    if (Buffer.isBuffer(req.body)) {
      rawBody = req.body;
    } else if (req.rawBody && Buffer.isBuffer(req.rawBody)) {
      rawBody = req.rawBody;
    } else if (typeof req.body === "string") {
      rawBody = Buffer.from(req.body, "utf8");
    } else if (req.body && Object.keys(req.body).length > 0) {
      rawBody = Buffer.from(JSON.stringify(req.body), "utf8");
    } else {
      rawBody = Buffer.alloc(0);
    }
    if (rawBody.length === 0) {
      console.warn("[Razorpay Webhook] Received empty request body.");
      return res.status(400).json({
        success: false,
        error: "Empty webhook request body."
      });
    }
    const isValid = verifyWebhookSignature(rawBody, signature);
    if (!isValid) {
      console.warn("[Razorpay Webhook] Invalid webhook signature rejected.");
      return res.status(400).json({
        success: false,
        error: "Invalid webhook signature."
      });
    }
    let payload;
    try {
      payload = JSON.parse(rawBody.toString("utf8"));
    } catch (parseErr) {
      console.warn("[Razorpay Webhook] Failed to parse verified JSON body:", parseErr?.message);
      return res.status(400).json({
        success: false,
        error: "Malformed JSON in signed webhook body."
      });
    }
    const event = payload?.event || "unknown";
    const paymentEntity = payload?.payload?.payment?.entity;
    const orderId = paymentEntity?.order_id || payload?.payload?.order?.entity?.id || null;
    const paymentId = paymentEntity?.id || null;
    switch (event) {
      case "payment.captured":
      case "order.paid": {
        console.log(
          `[Razorpay Webhook] Cryptographically verified event: ${event} (orderId: ${orderId}, paymentId: ${paymentId})`
        );
        let fulfillmentOutcome = { fulfilled: false };
        try {
          const notes = paymentEntity?.notes || payload?.payload?.order?.entity?.notes || {};
          let courseId = notes.courseId;
          let resourceId = notes.resourceId;
          let itemType = notes.itemType;
          let userId = notes.userId;
          if (!courseId && !resourceId && orderId) {
            const razorpay = getRazorpayClient();
            if (razorpay) {
              try {
                const fetchedOrder = await razorpay.orders.fetch(orderId);
                if (fetchedOrder?.notes) {
                  courseId = courseId || fetchedOrder.notes.courseId;
                  resourceId = resourceId || fetchedOrder.notes.resourceId;
                  itemType = itemType || fetchedOrder.notes.itemType;
                  userId = userId || fetchedOrder.notes.userId;
                }
              } catch (fetchErr) {
                console.warn("[Razorpay Webhook] Failed to fetch order notes from gateway:", fetchErr?.error?.description || fetchErr?.message || "Order not found");
              }
            }
          }
          const amountInPaise = paymentEntity?.amount || payload?.payload?.order?.entity?.amount || 0;
          const amountInRupees = amountInPaise / 100;
          const currency = (paymentEntity?.currency || payload?.payload?.order?.entity?.currency || "INR").toUpperCase();
          if (resourceId || itemType === "resource") {
            fulfillmentOutcome = await fulfillResourcePurchase({
              userId,
              resourceId,
              amount: amountInRupees,
              currency,
              orderId,
              paymentId,
              customerName: notes.customerName || "",
              customerEmail: notes.customerEmail || "",
              customerPhone: notes.customerPhone || "",
              resourceTitle: notes.resourceTitle || ""
            });
            console.log(
              `[Razorpay Webhook] Resource fulfillment result for payment ${paymentId}: fulfilled=${fulfillmentOutcome.fulfilled}, already_fulfilled=${fulfillmentOutcome.already_fulfilled}`
            );
          } else if (courseId && userId && isValidUUID(courseId) && isValidUUID(userId) && paymentId && orderId) {
            fulfillmentOutcome = await fulfillCourseEnrollment({
              userId,
              courseId,
              amount: amountInRupees,
              currency,
              orderId,
              paymentId
            });
            console.log(
              `[Razorpay Webhook] Course fulfillment result for payment ${paymentId}: fulfilled=${fulfillmentOutcome.fulfilled}, already_fulfilled=${fulfillmentOutcome.already_fulfilled}`
            );
          } else {
            console.warn(
              `[Razorpay Webhook] Insufficient trusted metadata to auto-fulfill webhook event: courseId=${courseId}, resourceId=${resourceId}, userId=${userId}, paymentId=${paymentId}`
            );
          }
        } catch (fErr) {
          console.error("[Razorpay Webhook] Error executing webhook fulfillment:", fErr?.message || fErr);
        }
        return res.status(200).json({
          status: "received",
          event,
          acknowledged: true,
          fulfilled: Boolean(fulfillmentOutcome.fulfilled),
          alreadyFulfilled: Boolean(fulfillmentOutcome.already_fulfilled)
        });
      }
      case "payment.failed":
        console.log(
          `[Razorpay Webhook] Cryptographically verified event: payment.failed (orderId: ${orderId}, paymentId: ${paymentId})`
        );
        return res.status(200).json({
          status: "received",
          event: "payment.failed",
          acknowledged: true,
          fulfilled: false
        });
      default:
        console.log(
          `[Razorpay Webhook] Cryptographically verified unhandled event: ${event} (acknowledged safely)`
        );
        return res.status(200).json({
          status: "received",
          event,
          acknowledged: true
        });
    }
  } catch (err) {
    console.error("[Razorpay Webhook] Unexpected internal error handling webhook:", err?.message || err);
    return res.status(500).json({
      success: false,
      error: "Internal error processing webhook."
    });
  }
}

// server/paymentRoutes.js
var import_express = __toESM(require("express"), 1);
var AUTHORITATIVE_PAID_RESOURCES = {
  // Bundle (All 4 tools)
  "2d50e5e3-711d-4461-a70d-0ed54dd29f17": { price: 299, accessType: "paid", currency: "INR" },
  "meta-ads-campaign-planner-bundle": { price: 299, accessType: "paid", currency: "INR" },
  // Deliverable 1: The Meta Ads Campaign Planner Workbook
  "27ef2c04-4d4a-4dbe-a702-d4013b2542b9": { price: 129, accessType: "paid", currency: "INR" },
  "meta-ads-campaign-planner-workbook": { price: 129, accessType: "paid", currency: "INR" },
  // Deliverable 2: Interactive Ad Budget & Break-Even Calculator
  "fafe5ffc-3323-4761-9d22-50a2588f6326": { price: 79, accessType: "paid", currency: "INR" },
  "the-ad-budget-breat-even-calculate": { price: 79, accessType: "paid", currency: "INR" },
  "the-ad-budget-break-even-calculator": { price: 79, accessType: "paid", currency: "INR" },
  // Deliverable 3: 10 High-Converting Meta Ads Copy Frameworks
  "004d374c-d872-4bfe-bf54-8083504e9174": { price: 79, accessType: "paid", currency: "INR" },
  "10-high-converting-meta-ads-copy-frameworks": { price: 79, accessType: "paid", currency: "INR" },
  // Deliverable 4: Pre-Launch & Tracking Audit Checklist
  "6867ecdd-2797-40f0-bdc8-ead20600ac6c": { price: 79, accessType: "paid", currency: "INR" },
  "pre-launch-tracking-audit-checklist": { price: 79, accessType: "paid", currency: "INR" }
};
function getAuthoritativeResourcePricing(idOrSlug, resourceRecord = null, fallbackBody = null) {
  const clean = String(idOrSlug || "").trim();
  const known = AUTHORITATIVE_PAID_RESOURCES[clean] || resourceRecord?.id && AUTHORITATIVE_PAID_RESOURCES[resourceRecord.id] || resourceRecord?.slug && AUTHORITATIVE_PAID_RESOURCES[resourceRecord.slug];
  const dbAccessType = resourceRecord?.access_type || resourceRecord?.accessType;
  const isExplicitlyPaidInDb = dbAccessType && String(dbAccessType).toLowerCase() === "paid" && Number(resourceRecord?.price) > 0;
  if (isExplicitlyPaidInDb) {
    return {
      accessType: "paid",
      price: Number(resourceRecord.price),
      currency: (resourceRecord.currency || "INR").toUpperCase()
    };
  }
  if (known) {
    return {
      accessType: "paid",
      price: known.price,
      currency: known.currency
    };
  }
  const fallbackAccessType = (fallbackBody?.accessType || dbAccessType || "free").toLowerCase();
  const fallbackPrice = Number(resourceRecord?.price) || Number(fallbackBody?.price) || 0;
  return {
    accessType: fallbackAccessType,
    price: fallbackPrice,
    currency: (resourceRecord?.currency || fallbackBody?.currency || "INR").toUpperCase()
  };
}
var router = import_express.default.Router();
router.post("/create-course-order", async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({
        success: false,
        error: "Authentication required. Please sign in to enroll."
      });
    }
    const { user, error: authError } = await verifySupabaseToken(authHeader);
    if (authError || !user) {
      return res.status(401).json({
        success: false,
        error: "Invalid or expired session. Please sign in again."
      });
    }
    const { courseId } = req.body || {};
    if (!courseId || !isValidUUID(courseId)) {
      return res.status(400).json({
        success: false,
        error: "A valid courseId (UUID) is required."
      });
    }
    const dbClient = getSupabaseDbClient(authHeader);
    if (!dbClient) {
      return res.status(503).json({
        success: false,
        error: "Database service is not currently available."
      });
    }
    const { data: course, error: courseError } = await dbClient.from("courses").select("id, title, price, offer_price, offer_expires_at, currency, status, max_seats, enrolled_count").eq("id", courseId).maybeSingle();
    if (courseError) {
      console.error("[Create Order] Supabase query error:", courseError.message);
      return res.status(500).json({
        success: false,
        error: "Failed to verify course details. Please try again."
      });
    }
    if (!course) {
      return res.status(404).json({
        success: false,
        error: "Course not found."
      });
    }
    if (course.status !== "published") {
      return res.status(400).json({
        success: false,
        error: `This course is currently not available for purchase (status: ${course.status}).`
      });
    }
    if (course.max_seats != null && course.max_seats > 0) {
      const enrolledCount = Number(course.enrolled_count) || 0;
      if (enrolledCount >= course.max_seats) {
        return res.status(400).json({
          success: false,
          error: "This course cohort has reached maximum capacity."
        });
      }
    }
    const { effectivePrice, currency } = calculateAuthoritativeCoursePrice(course);
    const amountInPaise = Math.round(effectivePrice * 100);
    if (amountInPaise <= 0) {
      return res.status(400).json({
        success: false,
        error: "This course is free and does not require payment processing."
      });
    }
    const { data: existingEnrollment, error: enrollmentError } = await dbClient.from("course_enrollments").select("id, status, expires_at").eq("user_id", user.id).eq("course_id", course.id).eq("status", "active").maybeSingle();
    if (enrollmentError) {
      console.warn("[Create Order] Enrollment pre-check warning:", enrollmentError.message);
    }
    if (existingEnrollment) {
      const expiresAt = existingEnrollment.expires_at ? new Date(existingEnrollment.expires_at) : null;
      const isNotExpired = !expiresAt || expiresAt.getTime() > Date.now();
      if (isNotExpired) {
        return res.status(409).json({
          success: false,
          alreadyEnrolled: true,
          message: "You already have active access to this course.",
          courseId: course.id,
          courseTitle: course.title
        });
      }
    }
    const razorpay = getRazorpayClient();
    if (!razorpay) {
      return res.status(503).json({
        success: false,
        error: "Payment gateway is not currently configured on the server."
      });
    }
    const receipt = `rcpt_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
    const orderOptions = {
      amount: amountInPaise,
      currency,
      receipt,
      notes: {
        courseId: course.id,
        userId: user.id,
        courseTitle: (course.title || "Course Masterclass").slice(0, 100)
      }
    };
    let order;
    try {
      order = await razorpay.orders.create(orderOptions);
    } catch (rzpErr) {
      console.error("[Create Order] Razorpay orders.create failed:", rzpErr?.message || rzpErr);
      return res.status(502).json({
        success: false,
        error: "Payment gateway failed to initialize order. Please try again."
      });
    }
    return res.status(200).json({
      success: true,
      orderId: order.id,
      amount: order.amount,
      currency: order.currency,
      keyId: getRazorpayKeyId(),
      courseId: course.id,
      courseTitle: course.title
    });
  } catch (err) {
    console.error("[Create Order] Unexpected error:", err?.message || err);
    return res.status(500).json({
      success: false,
      error: "An unexpected error occurred while creating your order."
    });
  }
});
router.post("/verify-course-payment", async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({
        success: false,
        verified: false,
        error: "Authentication required. Please sign in to verify payment."
      });
    }
    const { user, error: authError } = await verifySupabaseToken(authHeader);
    if (authError || !user) {
      return res.status(401).json({
        success: false,
        verified: false,
        error: "Invalid or expired session. Please sign in again."
      });
    }
    const {
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
      courseId
    } = req.body || {};
    if (!razorpay_order_id || typeof razorpay_order_id !== "string" || !razorpay_order_id.trim()) {
      return res.status(400).json({
        success: false,
        verified: false,
        error: "Missing or invalid razorpay_order_id."
      });
    }
    if (!razorpay_payment_id || typeof razorpay_payment_id !== "string" || !razorpay_payment_id.trim()) {
      return res.status(400).json({
        success: false,
        verified: false,
        error: "Missing or invalid razorpay_payment_id."
      });
    }
    if (!razorpay_signature || typeof razorpay_signature !== "string" || !razorpay_signature.trim()) {
      return res.status(400).json({
        success: false,
        verified: false,
        error: "Missing or invalid razorpay_signature."
      });
    }
    if (!courseId || !isValidUUID(courseId)) {
      return res.status(400).json({
        success: false,
        verified: false,
        error: "A valid courseId (UUID) is required."
      });
    }
    if (!isRazorpayConfigured()) {
      return res.status(503).json({
        success: false,
        verified: false,
        error: "Payment gateway credentials are not configured on the server."
      });
    }
    const isSignatureValid = verifyPaymentSignature(
      razorpay_order_id.trim(),
      razorpay_payment_id.trim(),
      razorpay_signature.trim()
    );
    if (!isSignatureValid) {
      console.warn(`[Payment Verification] Invalid signature rejected for user ${user.id}, order ${razorpay_order_id}`);
      return res.status(400).json({
        success: false,
        verified: false,
        error: "Payment verification failed: Invalid cryptographic signature."
      });
    }
    console.log(
      `[Payment Verification] Signature verified successfully for user ${user.id}, order ${razorpay_order_id}, payment ${razorpay_payment_id}`
    );
    const dbClient = getSupabaseDbClient(authHeader);
    if (!dbClient) {
      return res.status(503).json({
        success: false,
        verified: true,
        fulfilled: false,
        status: "verification_pending_fulfillment",
        error: "Database service is not currently available."
      });
    }
    const { data: course, error: courseError } = await dbClient.from("courses").select("id, slug, title, price, offer_price, offer_expires_at, currency, status").eq("id", courseId).maybeSingle();
    if (courseError || !course) {
      return res.status(404).json({
        success: false,
        verified: true,
        fulfilled: false,
        status: "fulfillment_rejected",
        error: "Course record not found for authoritative fulfillment verification."
      });
    }
    const { effectivePrice, currency } = calculateAuthoritativeCoursePrice(course);
    const fulfillment = await fulfillCourseEnrollment({
      userId: user.id,
      courseId: course.id,
      amount: effectivePrice,
      currency,
      orderId: razorpay_order_id.trim(),
      paymentId: razorpay_payment_id.trim()
    });
    if (fulfillment.fulfilled) {
      return res.status(200).json({
        success: true,
        verified: true,
        fulfilled: true,
        status: "completed",
        courseId: course.id,
        courseSlug: course.slug,
        courseTitle: course.title,
        orderId: razorpay_order_id.trim(),
        paymentId: razorpay_payment_id.trim(),
        enrollmentId: fulfillment.enrollment_id,
        paymentDbId: fulfillment.payment_id,
        alreadyFulfilled: fulfillment.already_fulfilled,
        message: "Payment cryptographically verified and course enrollment successfully fulfilled."
      });
    }
    if (fulfillment.code === "MIGRATION_PENDING" || fulfillment.code === "SERVICE_KEY_MISSING") {
      return res.status(200).json({
        success: true,
        verified: true,
        fulfilled: false,
        status: "verification_pending_fulfillment",
        courseId: course.id,
        courseSlug: course.slug,
        courseTitle: course.title,
        orderId: razorpay_order_id.trim(),
        paymentId: razorpay_payment_id.trim(),
        warning: fulfillment.error,
        message: "Payment signature verified. Automated course fulfillment is pending server migration or credentials."
      });
    }
    return res.status(400).json({
      success: false,
      verified: true,
      fulfilled: false,
      status: "fulfillment_rejected",
      error: fulfillment.error || "Course enrollment fulfillment was rejected."
    });
  } catch (err) {
    console.error("[Payment Verification] Unexpected error during verification:", err?.message || err);
    return res.status(500).json({
      success: false,
      verified: false,
      error: "An unexpected error occurred during payment verification."
    });
  }
});
router.post("/create-consultation-order", async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    let authenticatedUser = null;
    if (authHeader) {
      const { user } = await verifySupabaseToken(authHeader);
      authenticatedUser = user;
    }
    const { bookingDetails } = req.body || {};
    if (!bookingDetails) {
      return res.status(400).json({
        success: false,
        error: "Booking intake details are required."
      });
    }
    const { customerName, customerEmail, date, time } = bookingDetails;
    if (!customerName || !customerEmail || !date || !time) {
      return res.status(400).json({
        success: false,
        error: "Name, email, date, and time slot are required to initiate consultation booking."
      });
    }
    const dbClient = getSupabaseDbClient(authHeader) || getSupabaseServerClient();
    if (!dbClient) {
      return res.status(503).json({
        success: false,
        error: "Database service is not currently available."
      });
    }
    let { data: product, error: productError } = await dbClient.from("consultation_products").select("*").eq("active", true).limit(1).maybeSingle();
    if (productError || !product) {
      const { data: canonProduct } = await dbClient.from("consultation_products").select("*").eq("id", "31bbb9bf-ce10-4da4-a517-dfc673f9b875").maybeSingle();
      product = canonProduct;
    }
    const basePrice = Number(product?.base_price) || 499;
    const gstRate = Number(product?.gst_rate) || 0.18;
    const gstAmount = Number((basePrice * gstRate).toFixed(2));
    const totalAmount = Number((basePrice + gstAmount).toFixed(2));
    const amountInPaise = Math.round(totalAmount * 100);
    const currency = (product?.currency || "INR").toUpperCase();
    const razorpay = getRazorpayClient();
    if (!razorpay) {
      return res.status(503).json({
        success: false,
        error: "Payment gateway is not currently configured on the server."
      });
    }
    const receipt = `cnst_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
    const orderOptions = {
      amount: amountInPaise,
      currency,
      receipt,
      notes: {
        itemType: "consultation",
        productId: product?.id || "31bbb9bf-ce10-4da4-a517-dfc673f9b875",
        customerName: customerName.trim().slice(0, 50),
        customerEmail: customerEmail.trim().slice(0, 50),
        bookingDate: String(date).slice(0, 20),
        bookingTime: String(time).slice(0, 20),
        userId: authenticatedUser?.id || ""
      }
    };
    let order;
    try {
      order = await razorpay.orders.create(orderOptions);
    } catch (rzpErr) {
      console.error("[Create Consultation Order] Razorpay orders.create failed:", rzpErr?.message || rzpErr);
      return res.status(502).json({
        success: false,
        error: "Payment gateway failed to initialize order. Please try again."
      });
    }
    return res.json({
      success: true,
      orderId: order.id,
      amount: order.amount,
      currency: order.currency,
      keyId: getRazorpayKeyId(),
      productTitle: product?.name || "Business Growth Consultation",
      durationMinutes: product?.duration_minutes || 30,
      basePrice,
      gstAmount,
      totalAmount
    });
  } catch (err) {
    console.error("[Create Consultation Order] Unexpected error:", err);
    return res.status(500).json({
      success: false,
      error: "An unexpected error occurred while initializing consultation order."
    });
  }
});
router.post("/verify-consultation-payment", async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    let authenticatedUser = null;
    if (authHeader) {
      const { user } = await verifySupabaseToken(authHeader);
      authenticatedUser = user;
    }
    const {
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
      bookingDetails
    } = req.body || {};
    if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
      return res.status(400).json({
        success: false,
        verified: false,
        error: "Missing required Razorpay payment credentials for verification."
      });
    }
    if (!isRazorpayConfigured()) {
      return res.status(503).json({
        success: false,
        verified: false,
        error: "Payment gateway credentials are not configured on the server."
      });
    }
    const isSignatureValid = verifyPaymentSignature(
      razorpay_order_id.trim(),
      razorpay_payment_id.trim(),
      razorpay_signature.trim()
    );
    if (!isSignatureValid) {
      console.warn(`[Consultation Verification] Invalid signature rejected for order ${razorpay_order_id}`);
      return res.status(400).json({
        success: false,
        verified: false,
        error: "Payment verification failed: Invalid cryptographic signature."
      });
    }
    const fulfillment = await fulfillConsultationPayment({
      userId: authenticatedUser?.id || null,
      bookingDetails: bookingDetails || {},
      orderId: razorpay_order_id.trim(),
      paymentId: razorpay_payment_id.trim()
    });
    if (!fulfillment.success) {
      return res.status(500).json({
        success: false,
        verified: true,
        fulfilled: false,
        error: fulfillment.error || "Failed to finalize consultation booking record."
      });
    }
    return res.json({
      success: true,
      verified: true,
      fulfilled: true,
      already_fulfilled: Boolean(fulfillment.already_fulfilled),
      booking: fulfillment.booking,
      payment: fulfillment.payment,
      orderId: razorpay_order_id.trim(),
      paymentId: razorpay_payment_id.trim()
    });
  } catch (err) {
    console.error("[Consultation Verification] Unexpected error:", err);
    return res.status(500).json({
      success: false,
      verified: false,
      error: "An unexpected error occurred during consultation payment verification."
    });
  }
});
router.post("/create-resource-order", async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    let authenticatedUser = null;
    if (authHeader) {
      const { user } = await verifySupabaseToken(authHeader);
      authenticatedUser = user;
    }
    const { resourceId, customerDetails } = req.body || {};
    if (!resourceId || typeof resourceId !== "string") {
      return res.status(400).json({
        success: false,
        error: "A valid resourceId is required."
      });
    }
    const cleanResourceId = resourceId.trim();
    const dbClient = getSupabaseDbClient(authHeader) || getSupabaseServerClient();
    let resourceRecord = null;
    if (dbClient) {
      const isUUID = isValidUUID(cleanResourceId);
      const query = dbClient.from("resources").select("*");
      const { data, error } = isUUID ? await query.eq("id", cleanResourceId).maybeSingle() : await query.eq("slug", cleanResourceId).maybeSingle();
      if (!error && data) {
        resourceRecord = data;
      }
    }
    const pricing = getAuthoritativeResourcePricing(cleanResourceId, resourceRecord, req.body);
    if (pricing.accessType !== "paid" || pricing.price <= 0) {
      return res.status(400).json({
        success: false,
        error: "This resource is free and does not require payment processing."
      });
    }
    const authoritativePrice = pricing.price;
    const currency = pricing.currency;
    const amountInPaise = Math.round(authoritativePrice * 100);
    const razorpay = getRazorpayClient();
    if (!razorpay) {
      return res.status(503).json({
        success: false,
        error: "Payment gateway is not currently configured on the server."
      });
    }
    const receipt = `res_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
    const orderOptions = {
      amount: amountInPaise,
      currency,
      receipt,
      notes: {
        itemType: "resource",
        resourceId: resourceRecord?.id || cleanResourceId,
        resourceTitle: (resourceRecord?.title || resourceRecord?.name || "Digital Resource").slice(0, 100),
        customerName: (customerDetails?.name || "").slice(0, 50),
        customerEmail: (customerDetails?.email || "").slice(0, 50),
        userId: authenticatedUser?.id || ""
      }
    };
    let order;
    try {
      order = await razorpay.orders.create(orderOptions);
    } catch (rzpErr) {
      console.error("[Create Resource Order] Razorpay orders.create failed:", rzpErr?.message || rzpErr);
      return res.status(502).json({
        success: false,
        error: "Payment gateway failed to initialize order. Please try again."
      });
    }
    if (dbClient && (customerDetails?.email || customerDetails?.name)) {
      try {
        dbClient.from("crm_leads").insert({
          name: customerDetails?.name || "Resource Checkout Visitor",
          email: customerDetails?.email || "",
          phone: customerDetails?.phone || null,
          source: "Resource Paid Checkout Initiated",
          interest: resourceRecord?.title ? `Checkout: ${resourceRecord.title}` : `Resource ID: ${cleanResourceId}`,
          notes: `Checkout initiated for \u20B9${authoritativePrice}. Order ID: ${order.id}. Awaiting payment completion.`,
          status: "New",
          amount: authoritativePrice,
          created_at: (/* @__PURE__ */ new Date()).toISOString()
        }).then(({ error }) => {
          if (error) console.warn("[Create Resource Order] CRM lead capture notice:", error.message);
        });
      } catch (leadCatch) {
        console.warn("[Create Resource Order] Lead capture catch:", leadCatch?.message);
      }
    }
    return res.json({
      success: true,
      orderId: order.id,
      amount: order.amount,
      currency: order.currency,
      keyId: getRazorpayKeyId(),
      resourceId: resourceRecord?.id || cleanResourceId,
      resourceTitle: resourceRecord?.title || resourceRecord?.name || "Digital Resource Toolkit"
    });
  } catch (err) {
    console.error("[Create Resource Order] Unexpected error:", err);
    return res.status(500).json({
      success: false,
      error: "An unexpected error occurred while initializing resource order."
    });
  }
});
router.post("/verify-resource-payment", async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    let authenticatedUser = null;
    if (authHeader) {
      const { user } = await verifySupabaseToken(authHeader);
      authenticatedUser = user;
    }
    const {
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
      resourceId,
      customerDetails
    } = req.body || {};
    if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
      return res.status(400).json({
        success: false,
        verified: false,
        error: "Missing required Razorpay payment credentials for verification."
      });
    }
    if (!resourceId || typeof resourceId !== "string") {
      return res.status(400).json({
        success: false,
        verified: false,
        error: "Missing or invalid resourceId."
      });
    }
    if (!isRazorpayConfigured()) {
      return res.status(503).json({
        success: false,
        verified: false,
        error: "Payment gateway credentials are not configured on the server."
      });
    }
    const isSignatureValid = verifyPaymentSignature(
      razorpay_order_id.trim(),
      razorpay_payment_id.trim(),
      razorpay_signature.trim()
    );
    if (!isSignatureValid) {
      console.warn(`[Resource Verification] Invalid signature rejected for order ${razorpay_order_id}`);
      return res.status(400).json({
        success: false,
        verified: false,
        error: "Payment verification failed: Invalid cryptographic signature."
      });
    }
    const dbClient = getSupabaseDbClient(authHeader) || getSupabaseServerClient();
    let resourceRecord = null;
    if (dbClient) {
      const isUUID = isValidUUID(resourceId.trim());
      const query = dbClient.from("resources").select("*");
      const { data } = isUUID ? await query.eq("id", resourceId.trim()).maybeSingle() : await query.eq("slug", resourceId.trim()).maybeSingle();
      resourceRecord = data;
    }
    const pricing = getAuthoritativeResourcePricing(resourceId.trim(), resourceRecord, req.body);
    const amount = pricing.price;
    const currency = pricing.currency;
    const razorpay = getRazorpayClient();
    if (razorpay) {
      let rzpOrder = null;
      let rzpPayment = null;
      try {
        [rzpOrder, rzpPayment] = await Promise.all([
          razorpay.orders.fetch(razorpay_order_id.trim()),
          razorpay.payments.fetch(razorpay_payment_id.trim())
        ]);
      } catch (rzpFetchErr) {
        const errDesc = rzpFetchErr?.error?.description || rzpFetchErr?.message || "Payment or order not found on gateway.";
        console.warn(`[Resource Verification] Gateway fetch rejected: ${errDesc}`);
        return res.status(400).json({
          success: false,
          verified: false,
          error: `Payment verification failed on gateway: ${errDesc}`
        });
      }
      if (!rzpPayment || rzpPayment.status !== "captured") {
        console.warn(`[Resource Verification] Rejected uncaptured payment: status=${rzpPayment?.status}`);
        return res.status(400).json({
          success: false,
          verified: false,
          error: `Payment status is ${rzpPayment?.status || "unknown"}. Only captured payments can unlock resources.`
        });
      }
      if (rzpPayment.order_id && rzpPayment.order_id !== razorpay_order_id.trim()) {
        console.warn(`[Resource Verification] Mismatched order ID: payment.order_id=${rzpPayment.order_id}, expected=${razorpay_order_id}`);
        return res.status(400).json({
          success: false,
          verified: false,
          error: "Payment does not match the specified order ID."
        });
      }
      const expectedAmountInPaise = Math.round(amount * 100);
      if (expectedAmountInPaise > 0 && rzpPayment.amount !== expectedAmountInPaise) {
        console.warn(`[Resource Verification] Amount mismatch: paid ${rzpPayment.amount} paise, expected ${expectedAmountInPaise} paise`);
        return res.status(400).json({
          success: false,
          verified: false,
          error: "Payment amount does not match authoritative resource price."
        });
      }
      const expectedCurrency = currency.toUpperCase();
      if ((rzpPayment.currency || "").toUpperCase() !== expectedCurrency) {
        console.warn(`[Resource Verification] Currency mismatch: paid ${rzpPayment.currency}, expected ${expectedCurrency}`);
        return res.status(400).json({
          success: false,
          verified: false,
          error: "Payment currency does not match authoritative resource currency."
        });
      }
      if (rzpOrder) {
        if (rzpOrder.amount !== expectedAmountInPaise) {
          console.warn(`[Resource Verification] Order amount mismatch: order=${rzpOrder.amount}, expected=${expectedAmountInPaise}`);
          return res.status(400).json({
            success: false,
            verified: false,
            error: "Order amount does not match authoritative resource price."
          });
        }
        if ((rzpOrder.currency || "").toUpperCase() !== expectedCurrency) {
          return res.status(400).json({
            success: false,
            verified: false,
            error: "Order currency does not match authoritative resource currency."
          });
        }
        if (rzpOrder.notes?.resourceId && rzpOrder.notes.resourceId !== (resourceRecord?.id || resourceId.trim())) {
          console.warn(`[Resource Verification] Order resourceId note mismatch: note=${rzpOrder.notes.resourceId}, expected=${resourceRecord?.id}`);
          return res.status(400).json({
            success: false,
            verified: false,
            error: "Order was not created for this resource."
          });
        }
      }
    }
    const fulfillment = await fulfillResourcePurchase({
      userId: authenticatedUser?.id || null,
      resourceId: resourceRecord?.id || resourceId.trim(),
      amount,
      currency,
      orderId: razorpay_order_id.trim(),
      paymentId: razorpay_payment_id.trim(),
      customerName: customerDetails?.name || "",
      customerEmail: customerDetails?.email || authenticatedUser?.email || "",
      customerPhone: customerDetails?.phone || "",
      resourceTitle: resourceRecord?.title || resourceRecord?.name || "Digital Resource"
    });
    if (!fulfillment.success) {
      return res.status(500).json({
        success: false,
        verified: true,
        fulfilled: false,
        error: fulfillment.error || "Failed to finalize resource purchase record."
      });
    }
    return res.json({
      success: true,
      verified: true,
      fulfilled: true,
      already_fulfilled: Boolean(fulfillment.already_fulfilled),
      purchase: fulfillment.purchase,
      payment: fulfillment.payment,
      orderId: razorpay_order_id.trim(),
      paymentId: razorpay_payment_id.trim(),
      resourceId: resourceRecord?.id || resourceId.trim()
    });
  } catch (err) {
    console.error("[Resource Verification] Unexpected error:", err);
    return res.status(500).json({
      success: false,
      verified: false,
      error: "An unexpected error occurred during resource payment verification."
    });
  }
});
var BUNDLE_RESOURCE_ID = "2d50e5e3-711d-4461-a70d-0ed54dd29f17";
var BUNDLE_SLUG = "meta-ads-campaign-planner-bundle";
var BUNDLE_ITEMS = [
  {
    id: "27ef2c04-4d4a-4dbe-a702-d4013b2542b9",
    slug: "meta-ads-campaign-planner-workbook",
    title: "The Meta Ads Campaign Planner Workbook",
    description: "Step-by-step operating system, TOF/MOF/BOF architecture & 48-hour decision matrix.",
    format: "PDF Document (Workbook)",
    fileSize: "2.3 MB",
    filename: "meta-ads-campaign-planner-workbook.pdf",
    storagePath: "paid/meta-ads-campaign-planner-workbook.pdf"
  },
  {
    id: "fafe5ffc-3323-4761-9d22-50a2588f6326",
    slug: "the-ad-budget-breat-even-calculate",
    title: "Interactive Ad Budget & Break-Even Calculator",
    description: "Unit economics engine, target ROAS forecaster & volume scenario planner.",
    format: "Interactive Spreadsheet (.xlsx) & Protocol",
    fileSize: "29.5 KB",
    filename: "the-ad-budget-break-even-calculator.xlsx",
    storagePath: "paid/the-ad-budget-break-even-calculator.xlsx"
  },
  {
    id: "004d374c-d872-4bfe-bf54-8083504e9174",
    slug: "10-high-converting-meta-ads-copy-frameworks",
    title: "10 High-Converting Meta Ads Copy Frameworks",
    description: "Plug-and-play ad copy frameworks, headline swipe files & creative hook formulas.",
    format: "PDF Document (Swipe File)",
    fileSize: "1.9 MB",
    filename: "10-high-converting-meta-ads-copy-frameworks.pdf",
    storagePath: "paid/10-high-converting-meta-ads-copy-frameworks.pdf"
  },
  {
    id: "6867ecdd-2797-40f0-bdc8-ead20600ac6c",
    slug: "pre-launch-tracking-audit-checklist",
    title: "Pre-Launch & Tracking Audit Checklist",
    description: "1-page rapid audit protocol covering pixel verification, CAPI setup & checkout friction.",
    format: "PDF Checklist",
    fileSize: "943 KB",
    filename: "pre-launch-tracking-audit-checklist.pdf",
    storagePath: "paid/pre-launch-tracking-audit-checklist.pdf"
  }
];
function isBundleOrBundleItem(idOrSlug) {
  if (!idOrSlug) return { isBundle: false, isChild: false, item: null };
  const clean = String(idOrSlug).trim();
  if (clean === BUNDLE_RESOURCE_ID || clean === BUNDLE_SLUG) {
    return { isBundle: true, isChild: false, item: null };
  }
  const child = BUNDLE_ITEMS.find(
    (i) => i.id === clean || i.slug === clean || i.slug === "the-ad-budget-breat-even-calculate" && clean === "the-ad-budget-break-even-calculator"
  );
  if (child) {
    return { isBundle: false, isChild: true, item: child };
  }
  return { isBundle: false, isChild: false, item: null };
}
function getAllowedResourceIdsForAuthorization(targetResourceRecord) {
  const { isBundle, isChild } = isBundleOrBundleItem(targetResourceRecord.id || targetResourceRecord.slug);
  if (isChild) {
    return [targetResourceRecord.id, BUNDLE_RESOURCE_ID];
  }
  if (isBundle) {
    return [BUNDLE_RESOURCE_ID];
  }
  return [targetResourceRecord.id];
}
router.get("/verify-purchase-status", async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    let authenticatedUser = null;
    if (authHeader) {
      const { user } = await verifySupabaseToken(authHeader);
      authenticatedUser = user;
    }
    const { resourceId, orderId, paymentId } = req.query || {};
    if (!resourceId) {
      return res.status(400).json({ success: false, verified: false, error: "resourceId is required." });
    }
    const cleanResourceId = String(resourceId).trim();
    const cleanPaymentId = paymentId ? String(paymentId).trim() : null;
    const cleanOrderId = orderId ? String(orderId).trim() : null;
    const supabaseServer = getSupabaseServerClient() || getSupabaseDbClient(authHeader);
    if (!supabaseServer) {
      return res.status(503).json({ success: false, verified: false, error: "Database service unavailable." });
    }
    const isUUID = isValidUUID(cleanResourceId);
    const { data: resourceRecord } = isUUID ? await supabaseServer.from("resources").select("id, slug, title, access_type, price, currency").eq("id", cleanResourceId).maybeSingle() : await supabaseServer.from("resources").select("id, slug, title, access_type, price, currency").eq("slug", cleanResourceId).maybeSingle();
    if (!resourceRecord) {
      return res.status(404).json({
        success: false,
        verified: false,
        error: "Resource not found."
      });
    }
    const resolvedResId = resourceRecord.id;
    const pricing = getAuthoritativeResourcePricing(cleanResourceId, resourceRecord);
    const isFree = pricing.accessType !== "paid" || pricing.price <= 0;
    if (isFree) {
      return res.json({
        success: true,
        verified: true,
        isFree: true,
        resourceId: resolvedResId,
        resourceTitle: resourceRecord.title || "Free Resource",
        amount: 0,
        currency: "INR"
      });
    }
    const allowedResourceIds = getAllowedResourceIdsForAuthorization(resourceRecord);
    const expectedAmountInPaise = Math.round(pricing.price * 100);
    const expectedCurrency = pricing.currency;
    if (cleanPaymentId) {
      const { data: purchaseByPayId } = await supabaseServer.from("resource_purchases").select("*").eq("razorpay_payment_id", cleanPaymentId).in("resource_id", allowedResourceIds).eq("status", "active").maybeSingle();
      if (purchaseByPayId) {
        return res.json({
          success: true,
          verified: true,
          resourceId: resolvedResId,
          orderId: purchaseByPayId.razorpay_order_id,
          paymentId: purchaseByPayId.razorpay_payment_id,
          amount: Number(purchaseByPayId.amount) || Number(resourceRecord.price) || 0,
          currency: purchaseByPayId.currency || expectedCurrency
        });
      }
      const { data: paymentRecord } = await supabaseServer.from("payments").select("*").eq("razorpay_payment_id", cleanPaymentId).in("item_id", allowedResourceIds).eq("item_type", "resource").eq("status", "captured").maybeSingle();
      if (paymentRecord) {
        return res.json({
          success: true,
          verified: true,
          resourceId: resolvedResId,
          orderId: paymentRecord.razorpay_order_id,
          paymentId: paymentRecord.razorpay_payment_id,
          amount: Number(paymentRecord.amount) || Number(resourceRecord.price) || 0,
          currency: paymentRecord.currency || expectedCurrency
        });
      }
      const razorpay = getRazorpayClient();
      if (razorpay && cleanPaymentId.startsWith("pay_")) {
        try {
          const rzpPayment = await razorpay.payments.fetch(cleanPaymentId);
          if (rzpPayment && rzpPayment.status === "captured" && (rzpPayment.currency || "").toUpperCase() === expectedCurrency) {
            const isDirectMatch = Number(rzpPayment.amount) === expectedAmountInPaise;
            const isBundleMatch = allowedResourceIds.includes(BUNDLE_RESOURCE_ID) && Number(rzpPayment.amount) === 29900;
            if (isDirectMatch || isBundleMatch) {
              const orderIdToFetch = rzpPayment.order_id || cleanOrderId;
              if (orderIdToFetch) {
                const rzpOrder = await razorpay.orders.fetch(orderIdToFetch);
                const orderResNote = rzpOrder.notes?.resourceId;
                const orderMatchesResource = !orderResNote || allowedResourceIds.includes(orderResNote);
                if (orderMatchesResource) {
                  return res.json({
                    success: true,
                    verified: true,
                    resourceId: resolvedResId,
                    orderId: rzpOrder.id,
                    paymentId: rzpPayment.id,
                    amount: (rzpPayment.amount || 0) / 100,
                    currency: expectedCurrency
                  });
                }
              }
            }
          }
        } catch (rzpErr) {
        }
      }
    }
    if (authenticatedUser) {
      if (checkIsAdmin(authenticatedUser)) {
        return res.json({
          success: true,
          verified: true,
          isAdmin: true,
          resourceId: resolvedResId,
          amount: Number(resourceRecord?.price) || 0,
          currency: "INR"
        });
      }
      const { data: userPurchases } = await supabaseServer.from("resource_purchases").select("*").eq("user_id", authenticatedUser.id).in("resource_id", allowedResourceIds).eq("status", "active").maybeSingle();
      if (userPurchases) {
        return res.json({
          success: true,
          verified: true,
          resourceId: resolvedResId,
          orderId: userPurchases.razorpay_order_id,
          paymentId: userPurchases.razorpay_payment_id,
          amount: Number(userPurchases.amount) || Number(resourceRecord?.price) || 0,
          currency: userPurchases.currency || "INR"
        });
      }
      const { data: userPayment } = await supabaseServer.from("payments").select("*").eq("user_id", authenticatedUser.id).eq("item_type", "resource").in("item_id", allowedResourceIds).eq("status", "captured").maybeSingle();
      if (userPayment) {
        return res.json({
          success: true,
          verified: true,
          resourceId: resolvedResId,
          orderId: userPayment.razorpay_order_id,
          paymentId: userPayment.razorpay_payment_id,
          amount: Number(userPayment.amount) || Number(resourceRecord?.price) || 0,
          currency: userPayment.currency || "INR"
        });
      }
    }
    return res.json({
      success: true,
      verified: false,
      message: "No verified payment record found for this resource transaction."
    });
  } catch (err) {
    console.error("[Verify Purchase Status] Unexpected error:", err);
    return res.status(500).json({ success: false, verified: false, error: "Failed to verify purchase status." });
  }
});
router.post("/get-resource-download-url", async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    let authenticatedUser = null;
    if (authHeader) {
      const { user } = await verifySupabaseToken(authHeader);
      authenticatedUser = user;
    }
    const { resourceId, orderId, paymentId } = req.body || {};
    if (!resourceId) {
      return res.status(400).json({ success: false, error: "resourceId is required." });
    }
    const cleanResourceId = String(resourceId).trim();
    const cleanPaymentId = paymentId ? String(paymentId).trim() : null;
    const cleanOrderId = orderId ? String(orderId).trim() : null;
    const supabaseServer = getSupabaseServerClient() || getSupabaseDbClient(authHeader);
    if (!supabaseServer) {
      return res.status(503).json({ success: false, error: "Database service unavailable." });
    }
    const isUUID = isValidUUID(cleanResourceId);
    const { data: resourceRecord, error: rErr } = isUUID ? await supabaseServer.from("resources").select("*").eq("id", cleanResourceId).maybeSingle() : await supabaseServer.from("resources").select("*").eq("slug", cleanResourceId).maybeSingle();
    if (rErr || !resourceRecord) {
      return res.status(404).json({ success: false, error: "Resource not found." });
    }
    const pricing = getAuthoritativeResourcePricing(cleanResourceId, resourceRecord);
    const isPaid = pricing.accessType === "paid" && pricing.price > 0;
    if (!isPaid) {
      let freeDownloadUrl = resourceRecord.file_url || resourceRecord.external_url || null;
      const matchedBundleItem = BUNDLE_ITEMS.find((i) => i.id === resourceRecord.id || i.slug === resourceRecord.slug);
      if (matchedBundleItem) {
        const { data: sData } = await supabaseServer.storage.from("resources").createSignedUrl(matchedBundleItem.storagePath, 3600);
        if (sData?.signedUrl) {
          freeDownloadUrl = sData.signedUrl;
        }
      }
      return res.json({
        success: true,
        downloadUrl: freeDownloadUrl || "/downloads/META.pdf",
        externalUrl: null,
        fileUrl: freeDownloadUrl || "/downloads/META.pdf",
        accessType: "free"
      });
    }
    const allowedResourceIds = getAllowedResourceIdsForAuthorization(resourceRecord);
    let isAuthorized = false;
    if (cleanPaymentId) {
      const { data: pRecord } = await supabaseServer.from("payments").select("id, status, item_id, item_type").eq("razorpay_payment_id", cleanPaymentId).in("item_id", allowedResourceIds).eq("item_type", "resource").eq("status", "captured").maybeSingle();
      if (pRecord) {
        isAuthorized = true;
      }
      if (!isAuthorized) {
        const { data: purRecord } = await supabaseServer.from("resource_purchases").select("id, status, resource_id").eq("razorpay_payment_id", cleanPaymentId).in("resource_id", allowedResourceIds).eq("status", "active").maybeSingle();
        if (purRecord) {
          isAuthorized = true;
        }
      }
      if (!isAuthorized && cleanPaymentId.startsWith("pay_")) {
        const razorpay = getRazorpayClient();
        if (razorpay) {
          try {
            const rzpPayment = await razorpay.payments.fetch(cleanPaymentId);
            if (rzpPayment && rzpPayment.status === "captured") {
              const expectedAmountInPaise = Math.round(Number(resourceRecord.price) * 100);
              const matchesDirectAmount = Number(rzpPayment.amount) === expectedAmountInPaise;
              const matchesBundleAmount = allowedResourceIds.includes(BUNDLE_RESOURCE_ID) && Number(rzpPayment.amount) === 29900;
              const matchesCurrency = !resourceRecord.currency || (rzpPayment.currency || "").toUpperCase() === (resourceRecord.currency || "INR").toUpperCase();
              const paymentNoteResId = rzpPayment.notes?.resourceId || rzpPayment.notes?.resource_id;
              const matchesResNote = !paymentNoteResId || allowedResourceIds.includes(paymentNoteResId);
              if ((matchesDirectAmount || matchesBundleAmount) && matchesCurrency && matchesResNote) {
                isAuthorized = true;
              }
            }
          } catch {
          }
        }
      }
    }
    if (!isAuthorized && authenticatedUser) {
      if (checkIsAdmin(authenticatedUser)) {
        isAuthorized = true;
      } else {
        const { data: userPayment } = await supabaseServer.from("payments").select("id").eq("user_id", authenticatedUser.id).eq("item_type", "resource").in("item_id", allowedResourceIds).eq("status", "captured").maybeSingle();
        if (userPayment) {
          isAuthorized = true;
        } else {
          const { data: userPur } = await supabaseServer.from("resource_purchases").select("id").eq("user_id", authenticatedUser.id).in("resource_id", allowedResourceIds).eq("status", "active").maybeSingle();
          if (userPur) {
            isAuthorized = true;
          }
        }
      }
    }
    if (!isAuthorized) {
      return res.status(403).json({
        success: false,
        error: "Unauthorized: A confirmed payment is required to access this paid asset."
      });
    }
    if (resourceRecord.id === BUNDLE_RESOURCE_ID || resourceRecord.slug === BUNDLE_SLUG) {
      return res.json({
        success: true,
        isBundle: true,
        downloadUrl: `/resources/bundle/${BUNDLE_SLUG}`,
        bundleAccessUrl: `/resources/bundle/${BUNDLE_SLUG}`,
        resourceTitle: resourceRecord.title,
        accessType: "paid"
      });
    }
    let finalDownloadUrl = null;
    const bundleItem = BUNDLE_ITEMS.find(
      (i) => i.id === resourceRecord.id || i.slug === resourceRecord.slug || i.slug === "the-ad-budget-breat-even-calculate" && resourceRecord.slug === "the-ad-budget-break-even-calculator"
    );
    if (bundleItem) {
      const { data: signedData } = await supabaseServer.storage.from("resources").createSignedUrl(bundleItem.storagePath, 3600);
      if (signedData?.signedUrl) {
        finalDownloadUrl = signedData.signedUrl;
      }
    } else {
      let rawUrl = resourceRecord.file_url || resourceRecord.external_url || null;
      if (rawUrl && (rawUrl.includes("/storage/v1/object/") || rawUrl.startsWith("supabase://resources/"))) {
        let objectPath = "";
        if (rawUrl.startsWith("supabase://resources/")) {
          objectPath = rawUrl.replace("supabase://resources/", "");
        } else {
          const match = rawUrl.match(/\/resources\/(.+)$/);
          if (match && match[1]) {
            objectPath = decodeURIComponent(match[1].split("?")[0]);
          }
        }
        if (objectPath) {
          const { data: signedData } = await supabaseServer.storage.from("resources").createSignedUrl(objectPath, 3600);
          if (signedData?.signedUrl) {
            finalDownloadUrl = signedData.signedUrl;
          }
        }
      } else {
        finalDownloadUrl = rawUrl;
      }
    }
    return res.json({
      success: true,
      downloadUrl: finalDownloadUrl,
      externalUrl: null,
      // Never leak external URLs for paid assets
      fileUrl: finalDownloadUrl,
      resourceTitle: resourceRecord.title,
      accessType: "paid"
    });
  } catch (err) {
    console.error("[Get Resource Download URL] Unexpected error:", err);
    return res.status(500).json({ success: false, error: "Failed to generate authorized download URL." });
  }
});
async function handleBundleFilesRequest(req, res) {
  try {
    const authHeader = req.headers.authorization;
    let authenticatedUser = null;
    if (authHeader) {
      const { user } = await verifySupabaseToken(authHeader);
      authenticatedUser = user;
    }
    const { bundleId, orderId, paymentId } = req.method === "POST" ? req.body || {} : req.query || {};
    const cleanPaymentId = paymentId ? String(paymentId).trim() : null;
    const cleanOrderId = orderId ? String(orderId).trim() : null;
    const supabaseServer = getSupabaseServerClient() || getSupabaseDbClient(authHeader);
    if (!supabaseServer) {
      return res.status(503).json({ success: false, error: "Database service unavailable." });
    }
    let isAuthorized = false;
    if (cleanPaymentId) {
      const { data: pRecord } = await supabaseServer.from("payments").select("id, status, item_id, item_type").eq("razorpay_payment_id", cleanPaymentId).eq("item_id", BUNDLE_RESOURCE_ID).eq("item_type", "resource").eq("status", "captured").maybeSingle();
      if (pRecord) {
        isAuthorized = true;
      }
      if (!isAuthorized) {
        const { data: purRecord } = await supabaseServer.from("resource_purchases").select("id, status, resource_id").eq("razorpay_payment_id", cleanPaymentId).eq("resource_id", BUNDLE_RESOURCE_ID).eq("status", "active").maybeSingle();
        if (purRecord) {
          isAuthorized = true;
        }
      }
      if (!isAuthorized && cleanPaymentId.startsWith("pay_")) {
        const razorpay = getRazorpayClient();
        if (razorpay) {
          try {
            const rzpPayment = await razorpay.payments.fetch(cleanPaymentId);
            if (rzpPayment && rzpPayment.status === "captured") {
              const matchesAmount = Number(rzpPayment.amount) === 29900;
              const matchesCurrency = (rzpPayment.currency || "").toUpperCase() === "INR";
              const matchesOrder = !cleanOrderId || rzpPayment.order_id === cleanOrderId;
              const paymentNoteResId = rzpPayment.notes?.resourceId || rzpPayment.notes?.resource_id;
              const matchesNote = !paymentNoteResId || paymentNoteResId === BUNDLE_RESOURCE_ID || paymentNoteResId === BUNDLE_SLUG;
              if (matchesAmount && matchesCurrency && matchesOrder && matchesNote) {
                isAuthorized = true;
              }
            }
          } catch {
          }
        }
      }
    }
    if (!isAuthorized && authenticatedUser) {
      if (checkIsAdmin(authenticatedUser)) {
        isAuthorized = true;
      } else {
        const { data: userPayment } = await supabaseServer.from("payments").select("id").eq("user_id", authenticatedUser.id).eq("item_type", "resource").eq("item_id", BUNDLE_RESOURCE_ID).eq("status", "captured").maybeSingle();
        if (userPayment) {
          isAuthorized = true;
        } else {
          const { data: userPur } = await supabaseServer.from("resource_purchases").select("id").eq("user_id", authenticatedUser.id).eq("resource_id", BUNDLE_RESOURCE_ID).eq("status", "active").maybeSingle();
          if (userPur) {
            isAuthorized = true;
          }
        }
      }
    }
    if (!isAuthorized) {
      return res.status(403).json({
        success: false,
        authorized: false,
        error: "Unauthorized: A confirmed purchase of the Meta Ads Campaign Planner Bundle is required to access these assets.",
        bundle: {
          id: BUNDLE_RESOURCE_ID,
          slug: BUNDLE_SLUG,
          title: "Meta Ads Campaign Planner Bundle",
          price: 299,
          currency: "INR"
        }
      });
    }
    const signedFiles = [];
    for (const item of BUNDLE_ITEMS) {
      const { data: sData } = await supabaseServer.storage.from("resources").createSignedUrl(item.storagePath, 3600);
      signedFiles.push({
        id: item.id,
        slug: item.slug,
        title: item.title,
        description: item.description,
        format: item.format,
        fileSize: item.fileSize,
        filename: item.filename,
        downloadUrl: sData?.signedUrl || null
      });
    }
    return res.json({
      success: true,
      authorized: true,
      bundle: {
        id: BUNDLE_RESOURCE_ID,
        slug: BUNDLE_SLUG,
        title: "Meta Ads Campaign Planner Bundle",
        price: 299,
        currency: "INR"
      },
      files: signedFiles
    });
  } catch (err) {
    console.error("[Bundle Files] Unexpected error:", err);
    return res.status(500).json({ success: false, error: "Failed to generate authorized bundle downloads." });
  }
}
router.get("/bundle-files", handleBundleFilesRequest);
router.post("/get-bundle-files", handleBundleFilesRequest);
router.get("/admin/all-payments", async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({ success: false, error: "Authentication required." });
    }
    const { user, error: authError } = await verifySupabaseToken(authHeader);
    if (authError || !user) {
      return res.status(401).json({ success: false, error: "Invalid or expired administrator session." });
    }
    if (!checkIsAdmin(user)) {
      return res.status(403).json({ success: false, error: "Access denied. Administrator privileges required." });
    }
    const supabaseServer = getSupabaseServerClient() || getSupabaseDbClient(authHeader);
    if (!supabaseServer) {
      return res.status(503).json({ success: false, error: "Database service unavailable." });
    }
    const { data, error } = await supabaseServer.from("payments").select("*").order("created_at", { ascending: false });
    if (error) {
      console.error("[Admin Payments] Error querying payments table:", error);
      return res.status(500).json({ success: false, error: "Failed to retrieve payment records." });
    }
    return res.json({ success: true, payments: data || [] });
  } catch (err) {
    console.error("[Admin Payments] Unexpected error:", err);
    return res.status(500).json({ success: false, error: "Internal server error fetching payment ledger." });
  }
});
router.post("/admin/update-consultation-pricing", async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({ success: false, error: "Authentication required." });
    }
    const { user, error: authError } = await verifySupabaseToken(authHeader);
    if (authError || !user) {
      return res.status(401).json({ success: false, error: "Invalid or expired administrator session." });
    }
    if (!checkIsAdmin(user)) {
      return res.status(403).json({ success: false, error: "Access denied. Administrator privileges required." });
    }
    const { basePrice, gstRate, durationMinutes } = req.body || {};
    const parsedBase = Number(basePrice);
    const parsedGst = Number(gstRate);
    const parsedDuration = Number(durationMinutes);
    if (isNaN(parsedBase) || parsedBase < 0 || isNaN(parsedGst) || parsedGst < 0) {
      return res.status(400).json({ success: false, error: "Valid basePrice and gstRate are required." });
    }
    const supabaseServer = getSupabaseServerClient() || getSupabaseDbClient(authHeader);
    if (!supabaseServer) {
      return res.status(503).json({ success: false, error: "Database service unavailable." });
    }
    const targetId = "31bbb9bf-ce10-4da4-a517-dfc673f9b875";
    const updatePayload = {
      base_price: parsedBase,
      gst_rate: parsedGst,
      duration_minutes: !isNaN(parsedDuration) && parsedDuration > 0 ? parsedDuration : 30,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    const { data, error } = await supabaseServer.from("consultation_products").update(updatePayload).eq("id", targetId).select().maybeSingle();
    if (error) {
      console.error("[Admin Consultation Pricing] Update error:", error);
      return res.status(500).json({ success: false, error: "Failed to update consultation product." });
    }
    return res.json({ success: true, product: data });
  } catch (err) {
    console.error("[Admin Consultation Pricing] Unexpected error:", err);
    return res.status(500).json({ success: false, error: "Internal server error updating consultation product." });
  }
});
router.post("/webhook", (req, res) => {
  return handleRazorpayWebhook(req, res);
});
var paymentRoutes_default = router;

// server/webEnquiryRoutes.js
var import_express2 = __toESM(require("express"), 1);
var router2 = import_express2.default.Router();
function generateWebReferenceId() {
  const year = (/* @__PURE__ */ new Date()).getFullYear();
  const rand = Math.floor(1e3 + Math.random() * 9e3);
  return `WEB-${year}-${rand}`;
}
var submissionRateMap = /* @__PURE__ */ new Map();
function checkRateLimit(ip) {
  const now = Date.now();
  const windowMs = 15 * 60 * 1e3;
  const maxSubmissions = 10;
  const history = submissionRateMap.get(ip) || [];
  const recent = history.filter((ts) => now - ts < windowMs);
  if (recent.length >= maxSubmissions) {
    submissionRateMap.set(ip, recent);
    return false;
  }
  recent.push(now);
  submissionRateMap.set(ip, recent);
  return true;
}
router2.post("/submit", async (req, res) => {
  try {
    const clientIp = req.headers["x-forwarded-for"] || req.socket.remoteAddress || "client";
    if (!checkRateLimit(clientIp)) {
      return res.status(429).json({
        success: false,
        error: "Too many enquiries submitted from your network. Please wait a few minutes before trying again."
      });
    }
    const {
      projectType,
      businessName,
      businessStage,
      goals,
      features,
      contentReadiness,
      existingWebsiteUrl,
      referenceUrls,
      timeline,
      readiness,
      decisionMaker,
      additionalRequirements,
      fullName,
      email,
      phone,
      consentAgreed,
      idempotencyKey
    } = req.body || {};
    const cleanName = String(fullName || "").trim();
    const cleanEmail = String(email || "").trim().toLowerCase();
    const cleanPhone = String(phone || "").trim();
    const cleanBusiness = String(businessName || "").trim();
    const cleanProjectType = String(projectType || "").trim();
    const cleanBusinessStage = String(businessStage || "").trim();
    const cleanContentReadiness = String(contentReadiness || "").trim();
    const cleanTimeline = String(timeline || "").trim();
    const cleanReadiness = String(readiness || "").trim();
    const cleanDecisionMaker = String(decisionMaker || "").trim();
    if (!cleanName || cleanName.length < 2) {
      return res.status(400).json({ success: false, error: "Please enter your full name." });
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!cleanEmail || !emailRegex.test(cleanEmail)) {
      return res.status(400).json({ success: false, error: "Please enter a valid business email address." });
    }
    if (!cleanPhone || cleanPhone.length < 7) {
      return res.status(400).json({ success: false, error: "Please provide a valid phone or WhatsApp number." });
    }
    if (!cleanBusiness) {
      return res.status(400).json({ success: false, error: "Please provide your business or project name." });
    }
    if (!cleanProjectType) {
      return res.status(400).json({ success: false, error: "Please select the project type." });
    }
    const supabaseServer = getSupabaseServerClient();
    if (!supabaseServer) {
      return res.status(503).json({
        success: false,
        error: "Database service is temporarily unavailable. Please try again shortly."
      });
    }
    const structuredDetails = {
      projectType: cleanProjectType,
      businessName: cleanBusiness,
      businessStage: cleanBusinessStage,
      goals: Array.isArray(goals) ? goals.map((g) => String(g).trim()).filter(Boolean) : [],
      features: Array.isArray(features) ? features.map((f) => String(f).trim()).filter(Boolean) : [],
      contentReadiness: cleanContentReadiness,
      existingWebsiteUrl: existingWebsiteUrl ? String(existingWebsiteUrl).trim().slice(0, 500) : void 0,
      referenceUrls: referenceUrls ? String(referenceUrls).trim().slice(0, 500) : void 0,
      timeline: cleanTimeline,
      readiness: cleanReadiness,
      decisionMaker: cleanDecisionMaker,
      additionalRequirements: additionalRequirements ? String(additionalRequirements).trim().slice(0, 2e3) : void 0,
      consentAgreed: Boolean(consentAgreed),
      webStatus: "New",
      internalNotes: "",
      assignedTo: "",
      followUpDate: "",
      contactAttempts: 0
    };
    const referenceId = generateWebReferenceId();
    const notesJson = JSON.stringify(structuredDetails);
    const sixtySecondsAgo = new Date(Date.now() - 6e4).toISOString();
    const { data: recentDuplicate } = await supabaseServer.from("crm_leads").select("id, created_at, notes").eq("source", "Web Enquiry").eq("email", cleanEmail).gte("created_at", sixtySecondsAgo).maybeSingle();
    if (recentDuplicate) {
      return res.json({
        success: true,
        referenceId,
        alreadySubmitted: true,
        message: "Your enquiry has been received and logged. Our team will contact you shortly."
      });
    }
    const { data: inserted, error: insertError } = await supabaseServer.from("crm_leads").insert({
      name: cleanName.slice(0, 200),
      email: cleanEmail.slice(0, 200),
      phone: cleanPhone.slice(0, 50),
      source: "Web Enquiry",
      interest: `Website: ${cleanProjectType}`.slice(0, 200),
      notes: notesJson,
      status: "New"
    }).select().single();
    if (insertError) {
      console.error("[Web Enquiry] Insert error:", insertError);
      return res.status(500).json({
        success: false,
        error: "Failed to record your enquiry in the database. Please try again."
      });
    }
    return res.json({
      success: true,
      referenceId,
      id: inserted.id,
      message: "Thank you! Your website project enquiry has been submitted successfully."
    });
  } catch (err) {
    console.error("[Web Enquiry] Unexpected submission error:", err);
    return res.status(500).json({
      success: false,
      error: "An unexpected server error occurred while submitting your enquiry."
    });
  }
});
router2.get("/admin/all", async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({ success: false, error: "Authentication required." });
    }
    const { user, error: authError } = await verifySupabaseToken(authHeader);
    if (authError || !user) {
      return res.status(401).json({ success: false, error: "Invalid or expired administrator session." });
    }
    if (!checkIsAdmin(user)) {
      return res.status(403).json({ success: false, error: "Access denied. Administrator privileges required." });
    }
    const supabaseServer = getSupabaseServerClient();
    if (!supabaseServer) {
      return res.status(503).json({ success: false, error: "Database service unavailable." });
    }
    const { data, error } = await supabaseServer.from("crm_leads").select("*").eq("source", "Web Enquiry").order("created_at", { ascending: false });
    if (error) {
      console.error("[Web Enquiry Admin] Fetch error:", error);
      return res.status(500).json({ success: false, error: "Failed to retrieve web enquiries." });
    }
    return res.json({
      success: true,
      enquiries: data || []
    });
  } catch (err) {
    console.error("[Web Enquiry Admin] Unexpected fetch error:", err);
    return res.status(500).json({ success: false, error: "Internal server error fetching web enquiries." });
  }
});
router2.patch("/admin/:id", async (req, res) => {
  try {
    const { id } = req.params;
    if (!id || !isValidUUID(id)) {
      return res.status(400).json({ success: false, error: "Invalid enquiry ID format." });
    }
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({ success: false, error: "Authentication required." });
    }
    const { user, error: authError } = await verifySupabaseToken(authHeader);
    if (authError || !user) {
      return res.status(401).json({ success: false, error: "Invalid or expired administrator session." });
    }
    if (!checkIsAdmin(user)) {
      return res.status(403).json({ success: false, error: "Access denied. Administrator privileges required." });
    }
    const supabaseServer = getSupabaseServerClient();
    if (!supabaseServer) {
      return res.status(503).json({ success: false, error: "Database service unavailable." });
    }
    const { data: existing, error: fetchError } = await supabaseServer.from("crm_leads").select("*").eq("id", id).eq("source", "Web Enquiry").single();
    if (fetchError || !existing) {
      return res.status(404).json({ success: false, error: "Web enquiry record not found." });
    }
    let parsedNotes = {};
    try {
      parsedNotes = existing.notes ? JSON.parse(existing.notes) : {};
    } catch {
      parsedNotes = { rawNotes: existing.notes };
    }
    const { status, internalNotes, assignedTo, followUpDate, contactAttempts } = req.body || {};
    if (status !== void 0) {
      parsedNotes.webStatus = status;
    }
    if (internalNotes !== void 0) {
      parsedNotes.internalNotes = String(internalNotes);
    }
    if (assignedTo !== void 0) {
      parsedNotes.assignedTo = String(assignedTo);
    }
    if (followUpDate !== void 0) {
      parsedNotes.followUpDate = String(followUpDate);
    }
    if (contactAttempts !== void 0) {
      parsedNotes.contactAttempts = Number(contactAttempts);
    }
    let crmLeadStatus = "New";
    if (status === "Contacted") crmLeadStatus = "Contacted";
    else if (status === "Qualified" || status === "Proposal Sent") crmLeadStatus = "Qualified";
    else if (status === "Won") crmLeadStatus = "Converted";
    else if (status === "Lost") crmLeadStatus = "Lost";
    const { data: updated, error: updateError } = await supabaseServer.from("crm_leads").update({
      notes: JSON.stringify(parsedNotes),
      status: crmLeadStatus,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("id", id).select().single();
    if (updateError) {
      console.error("[Web Enquiry Admin] Update error:", updateError);
      return res.status(500).json({ success: false, error: "Failed to update web enquiry in database." });
    }
    return res.json({
      success: true,
      enquiry: updated
    });
  } catch (err) {
    console.error("[Web Enquiry Admin] Unexpected update error:", err);
    return res.status(500).json({ success: false, error: "Internal server error updating web enquiry." });
  }
});
router2.delete("/admin/:id", async (req, res) => {
  try {
    const { id } = req.params;
    if (!id || !isValidUUID(id)) {
      return res.status(400).json({ success: false, error: "Invalid enquiry ID format." });
    }
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({ success: false, error: "Authentication required." });
    }
    const { user, error: authError } = await verifySupabaseToken(authHeader);
    if (authError || !user) {
      return res.status(401).json({ success: false, error: "Invalid or expired administrator session." });
    }
    if (!checkIsAdmin(user)) {
      return res.status(403).json({ success: false, error: "Access denied. Administrator privileges required." });
    }
    const supabaseServer = getSupabaseServerClient();
    if (!supabaseServer) {
      return res.status(503).json({ success: false, error: "Database service unavailable." });
    }
    const { error: deleteError } = await supabaseServer.from("crm_leads").delete().eq("id", id).eq("source", "Web Enquiry");
    if (deleteError) {
      console.error("[Web Enquiry Admin] Delete error:", deleteError);
      return res.status(500).json({ success: false, error: "Failed to delete web enquiry." });
    }
    return res.json({ success: true, message: "Enquiry deleted successfully." });
  } catch (err) {
    console.error("[Web Enquiry Admin] Unexpected delete error:", err);
    return res.status(500).json({ success: false, error: "Internal server error deleting web enquiry." });
  }
});
var webEnquiryRoutes_default = router2;

// server/growthAuditRoutes.js
var import_express3 = __toESM(require("express"), 1);
var router3 = import_express3.default.Router();
function generateAuditReferenceId() {
  const year = (/* @__PURE__ */ new Date()).getFullYear();
  const rand = Math.floor(1e3 + Math.random() * 9e3);
  return `GA-${year}-${rand}`;
}
var rateLimitMap = /* @__PURE__ */ new Map();
function checkRateLimit2(ip) {
  const now = Date.now();
  const windowMs = 15 * 60 * 1e3;
  const maxRequests = 20;
  const history = rateLimitMap.get(ip) || [];
  const recent = history.filter((ts) => now - ts < windowMs);
  if (recent.length >= maxRequests) {
    rateLimitMap.set(ip, recent);
    return false;
  }
  recent.push(now);
  rateLimitMap.set(ip, recent);
  return true;
}
var bookingIdempotencyCache = /* @__PURE__ */ new Map();
function evaluateQualification(revenueBand, adSpendBand) {
  const qualifyingRevenues = [
    "\u20B93 lakh\u2013\u20B910 lakh",
    "\u20B910 lakh\u2013\u20B925 lakh",
    "Above \u20B925 lakh"
  ];
  const qualifyingAdSpends = [
    "Under \u20B925,000",
    "\u20B925,000\u2013\u20B950,000",
    "\u20B950,001\u2013\u20B91 lakh",
    "Above \u20B91 lakh"
  ];
  const isPreRevenue = revenueBand === "Pre-revenue / launching soon" || adSpendBand === "Campaigns launching soon";
  const meetsRevenue = qualifyingRevenues.includes(revenueBand);
  const meetsAdSpend = qualifyingAdSpends.includes(adSpendBand);
  if (meetsRevenue && meetsAdSpend) {
    return {
      status: "qualified",
      pathway: "Route B \u2014 Qualified Growth Audit",
      reason: "Qualified: Monthly revenue \u20B93L+ with active monthly ad spend."
    };
  }
  if (isPreRevenue) {
    return {
      status: "startup_review",
      pathway: "Route A \u2014 Academy Pathway (Startup Edition)",
      reason: "Pre-revenue / Launching soon: Recommended for Academy foundational architecture."
    };
  }
  return {
    status: "academy_nurture",
    pathway: "Route A \u2014 Academy Pathway",
    reason: "Stage alignment: Academy curriculum recommended prior to agency retainer."
  };
}
router3.post("/submit", async (req, res) => {
  try {
    const clientIp = req.headers["x-forwarded-for"] || req.socket.remoteAddress || "client";
    if (!checkRateLimit2(clientIp)) {
      return res.status(429).json({
        success: false,
        error: "Too many audit requests from your network. Please wait a few minutes before trying again."
      });
    }
    const {
      name,
      email,
      website,
      hasNoWebsite,
      monthlyRevenue,
      monthlyAdSpend,
      growthBottleneck,
      marketingConsent,
      utmSource,
      utmMedium,
      utmCampaign,
      utmContent,
      utmTerm,
      landingPage,
      idempotencyKey
    } = req.body || {};
    const cleanName = String(name || "").trim();
    const cleanEmail = String(email || "").trim().toLowerCase();
    const cleanWebsite = hasNoWebsite ? "No website yet" : String(website || "").trim();
    const cleanRevenue = String(monthlyRevenue || "").trim();
    const cleanAdSpend = String(monthlyAdSpend || "").trim();
    const cleanBottleneck = String(growthBottleneck || "").trim();
    const cleanConsent = Boolean(marketingConsent);
    if (!cleanName || cleanName.length < 2) {
      return res.status(400).json({ success: false, error: "Please provide your name." });
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!cleanEmail || !emailRegex.test(cleanEmail)) {
      return res.status(400).json({ success: false, error: "Please enter a valid business email address." });
    }
    if (!cleanRevenue) {
      return res.status(400).json({ success: false, error: "Please select your average monthly business revenue." });
    }
    if (!cleanAdSpend) {
      return res.status(400).json({ success: false, error: "Please select your current monthly advertising spend." });
    }
    const qualification = evaluateQualification(cleanRevenue, cleanAdSpend);
    const referenceId = generateAuditReferenceId();
    const notesPayload = {
      reference_id: referenceId,
      website_url: cleanWebsite,
      monthly_revenue_band: cleanRevenue,
      monthly_ad_spend_band: cleanAdSpend,
      primary_growth_challenge: cleanBottleneck || "General Growth Audit",
      qualification_status: qualification.status,
      qualification_reason: qualification.reason,
      lead_source: "Growth Audit Qualification Form",
      landing_page: landingPage || "/request-growth-audit",
      utm_source: utmSource || null,
      utm_medium: utmMedium || null,
      utm_campaign: utmCampaign || null,
      utm_content: utmContent || null,
      utm_term: utmTerm || null,
      marketing_consent: cleanConsent,
      booking_status: qualification.status === "qualified" ? "pending_calendar_selection" : "nurture",
      submitted_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    const supabaseServer = getSupabaseServerClient();
    let dbRecordId = null;
    if (supabaseServer) {
      try {
        const { data: inserted, error: dbError } = await supabaseServer.from("crm_leads").insert({
          name: cleanName.slice(0, 200),
          email: cleanEmail.slice(0, 200),
          source: "Consultation Intake Brief",
          interest: `Growth Audit: ${cleanRevenue} rev | ${cleanAdSpend} ad spend`.slice(0, 200),
          notes: JSON.stringify(notesPayload),
          status: qualification.status === "qualified" ? "Qualified" : "New"
        }).select("id").single();
        if (inserted) {
          dbRecordId = inserted.id;
        } else if (dbError) {
          console.warn("[Growth Audit] Database insert notice:", dbError.message);
        }
      } catch (err) {
        console.warn("[Growth Audit] Non-fatal database notice:", err.message);
      }
    }
    return res.json({
      success: true,
      referenceId,
      dbRecordId,
      qualificationStatus: qualification.status,
      pathway: qualification.pathway,
      reason: qualification.reason,
      leadSummary: {
        name: cleanName,
        email: cleanEmail,
        website: cleanWebsite,
        monthlyRevenue: cleanRevenue,
        monthlyAdSpend: cleanAdSpend,
        growthBottleneck: cleanBottleneck
      }
    });
  } catch (error) {
    console.error("[Growth Audit Submit] Error:", error);
    return res.status(500).json({
      success: false,
      error: "An unexpected error occurred while processing your qualification. Please try again."
    });
  }
});
router3.post("/book", async (req, res) => {
  try {
    const {
      referenceId,
      name,
      email,
      phone,
      website,
      date,
      time,
      notes
    } = req.body || {};
    const cleanRef = String(referenceId || generateAuditReferenceId()).trim();
    const cleanName = String(name || "").trim();
    const cleanEmail = String(email || "").trim().toLowerCase();
    const cleanPhone = String(phone || "").trim();
    const cleanDate = String(date || "").trim();
    const cleanTime = String(time || "").trim();
    const cleanWebsite = String(website || "Not provided").trim();
    if (!cleanName || !cleanEmail || !cleanDate || !cleanTime) {
      return res.status(400).json({
        success: false,
        error: "Missing required booking details (Name, Email, Date, and Time slot)."
      });
    }
    const idempotencyKey = `${cleanRef}_${cleanDate}_${cleanTime}`;
    if (bookingIdempotencyCache.has(idempotencyKey)) {
      const cached = bookingIdempotencyCache.get(idempotencyKey);
      return res.json(cached);
    }
    const appointmentDateTime = `${cleanDate} at ${cleanTime}`;
    const timezone = "IST (Asia/Kolkata)";
    const whatsAppMessage = `Hi ${cleanName}, Muid here. Your Growth Audit is confirmed for ${appointmentDateTime} (${timezone}). I\u2019ll review your website and growth setup before we talk. If you need to make any changes, please use your booking confirmation link.`;
    const internalAlertText = `\u{1F6A8} High-Ticket Growth Audit Booked \u2014 ${cleanName} \u2014 ${appointmentDateTime} \u2014 ${cleanWebsite}`;
    const supabaseServer = getSupabaseServerClient();
    if (supabaseServer) {
      try {
        const updatePayload = {
          booking_status: "confirmed",
          booking_reference: cleanRef,
          appointment_datetime: appointmentDateTime,
          appointment_timezone: timezone,
          customer_phone: cleanPhone || null,
          confirmed_at: (/* @__PURE__ */ new Date()).toISOString(),
          whatsapp_template_queued: true,
          internal_alert_queued: true
        };
        const { data: existingLead } = await supabaseServer.from("crm_leads").select("id, notes").eq("email", cleanEmail).order("created_at", { ascending: false }).limit(1).maybeSingle();
        if (existingLead) {
          let mergedNotes = updatePayload;
          try {
            if (existingLead.notes) {
              const parsed = JSON.parse(existingLead.notes);
              mergedNotes = { ...parsed, ...updatePayload };
            }
          } catch (_) {
          }
          await supabaseServer.from("crm_leads").update({
            status: "Qualified",
            phone: cleanPhone || null,
            notes: JSON.stringify(mergedNotes)
          }).eq("id", existingLead.id);
        }
      } catch (err) {
        console.warn("[Growth Audit Booking] Non-fatal CRM update notice:", err.message);
      }
    }
    const responsePayload = {
      success: true,
      bookingReference: cleanRef,
      appointmentDateTime,
      timezone,
      status: "confirmed",
      whatsAppConfirmation: {
        status: cleanPhone ? "delivered_to_queue" : "skipped_no_phone",
        recipient: cleanPhone || "No WhatsApp number provided",
        message: whatsAppMessage
      },
      internalAlert: {
        status: "dispatched",
        alertText: internalAlertText
      }
    };
    bookingIdempotencyCache.set(idempotencyKey, responsePayload);
    setTimeout(() => {
      bookingIdempotencyCache.delete(idempotencyKey);
    }, 5 * 60 * 1e3);
    return res.json(responsePayload);
  } catch (error) {
    console.error("[Growth Audit Booking] Error:", error);
    return res.status(500).json({
      success: false,
      error: "Unable to finalize your appointment reservation. Please try again."
    });
  }
});
var growthAuditRoutes_default = router3;

// server/seoRedirects.js
function seoRedirectMiddleware(req, res, next) {
  const host = (req.headers.host || "").toLowerCase();
  const rawPath = req.path || "/";
  const queryPart = req.url && req.url.includes("?") ? req.url.slice(req.url.indexOf("?")) : "";
  if (host.startsWith("www.")) {
    const nonWwwHost = host.replace(/^www\./, "");
    const protocol = req.headers["x-forwarded-proto"] || req.protocol || "https";
    return res.redirect(301, `${protocol}://${nonWwwHost}${req.url}`);
  }
  if (host.includes("learnskill.digitalmuid.in") || host.startsWith("learnskill.")) {
    const normalizedSubPath = rawPath.length > 1 ? rawPath.replace(/\/+$/, "") : rawPath;
    if (normalizedSubPath === "/courses/complete-meta-ads-mastery-course-why-its-essential-to-start-early-in-your-career" || normalizedSubPath.includes("complete-meta-ads-mastery-course")) {
      return res.redirect(301, "https://digitalmuid.in/learn/meta-ads-mastery" + queryPart);
    }
    if (normalizedSubPath === "/terms-conditions" || normalizedSubPath === "/terms") {
      return res.redirect(301, "https://digitalmuid.in/terms" + queryPart);
    }
    if (normalizedSubPath === "" || normalizedSubPath === "/" || normalizedSubPath.startsWith("/courses") || normalizedSubPath.startsWith("/learn")) {
      return res.redirect(301, "https://digitalmuid.in/learn" + queryPart);
    }
    return res.redirect(301, "https://digitalmuid.in/learn" + queryPart);
  }
  const normalizedPath = rawPath.length > 1 ? rawPath.replace(/\/+$/, "") : rawPath;
  if (normalizedPath === "/services-3") {
    return res.redirect(301, "/services" + queryPart);
  }
  if (normalizedPath === "/services-3/social-media-marketing") {
    return res.redirect(301, "/services/modern-marketing" + queryPart);
  }
  if (normalizedPath === "/smm-packages-in-lucknow") {
    return res.redirect(301, "/services/modern-marketing" + queryPart);
  }
  if (normalizedPath === "/courses/complete-meta-ads-mastery-course-why-its-essential-to-start-early-in-your-career" || normalizedPath.includes("complete-meta-ads-mastery-course")) {
    return res.redirect(301, "/learn/meta-ads-mastery" + queryPart);
  }
  if (normalizedPath === "/price") {
    res.status(410);
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    return res.send(`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>410 Gone \u2014 Pricing Page Retired | DigitalMUID</title>
  <meta name="robots" content="noindex, follow">
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #07111F; color: #E2E8F0; padding: 60px 20px; text-align: center; line-height: 1.6; }
    .box { max-width: 600px; margin: 0 auto; background: #0A1A2F; border: 1px solid #1E293B; border-radius: 16px; padding: 40px; }
    h1 { color: #FF6B00; font-size: 28px; margin-bottom: 12px; }
    p { color: #94A3B8; font-size: 15px; margin-bottom: 24px; }
    a { display: inline-block; background: #FF6B00; color: #FFF; padding: 12px 24px; border-radius: 10px; text-decoration: none; font-weight: 600; font-size: 14px; }
    a.sec { background: transparent; border: 1px solid #334155; color: #CBD5E1; margin-left: 10px; }
  </style>
</head>
<body>
  <div class="box">
    <h1>410 \u2014 Pricing Packages Discontinued</h1>
    <p>DigitalMUID has transitioned from static, off-the-shelf pricing packages to bespoke client advisory and customized project scoping. Please explore our strategic services or book a growth consultation to discuss your specific requirements.</p>
    <a href="/services">Explore Services</a>
    <a href="/business-growth-consultation" class="sec">Book Consultation</a>
  </div>
</body>
</html>`);
  }
  if (normalizedPath === "/terms-conditions") {
    return res.redirect(301, "/terms" + queryPart);
  }
  if (normalizedPath === "/sitemap_index.xml" || normalizedPath === "/sitemap_index" || normalizedPath === "/page-sitemap.xml" || normalizedPath === "/post-sitemap.xml" || normalizedPath === "/category-sitemap.xml") {
    return res.redirect(301, "https://digitalmuid.in/sitemap.xml");
  }
  if (normalizedPath === "/consultation") {
    return res.redirect(301, "/business-growth-consultation" + queryPart);
  }
  if (normalizedPath === "/courses") {
    return res.redirect(301, "/learn" + queryPart);
  }
  if (normalizedPath === "/web-services" || normalizedPath === "/web-development" || normalizedPath === "/web-design") {
    return res.redirect(301, "/web" + queryPart);
  }
  if (rawPath.length > 1 && rawPath.endsWith("/") && !rawPath.startsWith("/api/")) {
    const strippedPath = rawPath.replace(/\/+$/, "");
    return res.redirect(301, strippedPath + queryPart);
  }
  next();
}

// server/seoData.js
var BASE_URL = "https://digitalmuid.in";
var SEO_DATA = {
  "/": {
    path: "/",
    canonicalUrl: "https://digitalmuid.in/",
    title: "Digital Muid \u2014 Growth Strategist | Founder | Educator | AI & Digital Transformation",
    description: "I help businesses and professionals understand the changing digital world\u2014and turn knowledge into meaningful growth. Strategic consulting, practical AI frameworks, courses, and resources.",
    ogTitle: "Digital Muid \u2014 Growth Strategist | Founder | Educator",
    ogDescription: "Turn digital knowledge into meaningful growth. Frameworks, education, and strategic consultation.",
    ogType: "website",
    schema: {
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": "Organization",
          "@id": "https://digitalmuid.in/#organization",
          name: "DigitalMUID",
          url: "https://digitalmuid.in/",
          logo: "https://digitalmuid.in/favicon.ico",
          founder: {
            "@type": "Person",
            name: "Digital Muid",
            jobTitle: "Growth Strategist & AI Transformation Consultant",
            url: "https://digitalmuid.in/about"
          },
          sameAs: [
            "https://www.linkedin.com/in/digitalmuid",
            "https://www.instagram.com/digitalmuid",
            "https://www.youtube.com/@digitalmuid"
          ]
        },
        {
          "@type": "WebSite",
          "@id": "https://digitalmuid.in/#website",
          url: "https://digitalmuid.in/",
          name: "DigitalMUID",
          publisher: { "@id": "https://digitalmuid.in/#organization" }
        }
      ]
    },
    semanticHtml: `
      <header>
        <h1>Digital Muid \u2014 Growth Strategist, Founder & AI Transformation Consultant</h1>
        <p>Turning digital knowledge into predictable business growth through AI frameworks, education, and advisory.</p>
      </header>
      <main>
        <nav aria-label="Main Navigation">
          <ul>
            <li><a href="/web">Web Design & Development Services</a></li>
            <li><a href="/learn">Practical Digital Education & Courses</a></li>
            <li><a href="/business-growth-consultation">Book a Business Growth Consultation</a></li>
            <li><a href="/services">Strategic Advisory Services</a></li>
            <li><a href="/contact">Get in Touch</a></li>
          </ul>
        </nav>
      </main>
    `
  },
  "/web": {
    path: "/web",
    canonicalUrl: "https://digitalmuid.in/web",
    title: "Website Design & Development Services | DigitalMUID",
    description: "Professional website design and custom development by DigitalMUID. We build high-converting business websites, LMS portals, booking systems, and e-commerce platforms.",
    ogTitle: "Website Design & Development Services | DigitalMUID",
    ogDescription: "Custom business websites, LMS portals, booking platforms, and web applications built for speed, conversion, and scale.",
    ogType: "website",
    schema: {
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": "ProfessionalService",
          "@id": "https://digitalmuid.in/#organization",
          name: "DigitalMUID Web Design & Development",
          url: "https://digitalmuid.in/web",
          description: "Professional website design and custom web development services for ambitious brands, founders, and growing enterprises.",
          serviceType: "Website Design, Web Development, LMS Systems, Booking Platforms, E-Commerce Portals",
          areaServed: "Worldwide",
          provider: {
            "@type": "Person",
            name: "Digital Muid"
          }
        },
        {
          "@type": "WebPage",
          "@id": "https://digitalmuid.in/web#webpage",
          url: "https://digitalmuid.in/web",
          name: "Website Design & Development Services | DigitalMUID",
          description: "Professional website design and custom development by DigitalMUID. We build high-converting business websites, LMS portals, booking systems, and e-commerce platforms."
        }
      ]
    },
    semanticHtml: `
      <article>
        <header>
          <h1>Website Design & Custom Web Development Services</h1>
          <p>We build high-converting business websites, LMS portals, booking platforms, and custom digital applications designed for authority, speed, and real revenue generation.</p>
        </header>
        <section>
          <h2>Core Web Solutions & Deliverables</h2>
          <ul>
            <li><strong>New Business Websites:</strong> Clean, high-converting digital foundations with modern typography, fast loading speeds, and responsive mobile architecture.</li>
            <li><strong>Website Redesigns:</strong> Modernize legacy, slow, or low-converting websites into authoritative brand assets.</li>
            <li><strong>LMS & E-Learning Portals:</strong> Course player interfaces, student dashboards, secure video streaming, and automated certificate verification.</li>
            <li><strong>Online Booking & Consultation Systems:</strong> Real-time calendar synchronization, payment gateways (Razorpay/Stripe), and client scheduling.</li>
            <li><strong>E-Commerce & Digital Commerce:</strong> Scalable product catalogs, secure checkout flows, and automated customer notifications.</li>
            <li><strong>Custom Web Applications:</strong> Bespoke full-stack React, TypeScript, and modern API-driven web systems.</li>
          </ul>
        </section>
        <section>
          <h2>Our Development Standards</h2>
          <p>Every website built by DigitalMUID adheres to strict production engineering: Lighthouse scores above 90, sub-second load times, mobile-first responsive layout, search engine structured data, and hardened SSL security.</p>
        </section>
        <section>
          <h2>Start Your Project Enquiry</h2>
          <p>Discuss your project scope, timeline, and custom requirements directly with our engineering team.</p>
          <p><a href="/contact">Submit a Project Enquiry</a> or <a href="/business-growth-consultation">Schedule an Advisory Consultation</a>.</p>
        </section>
      </article>
    `
  },
  "/academy": {
    path: "/academy",
    canonicalUrl: "https://digitalmuid.in/academy",
    title: "Digital MUID Academy | Digital Marketing & AI Education",
    description: "Explore practical digital marketing, advertising, SEO, and AI education for students, freelancers, and growth operators at Digital MUID Academy.",
    ogTitle: "Digital MUID Academy | Digital Marketing & AI Education",
    ogDescription: "Explore practical digital marketing, advertising, SEO, and AI education for students, freelancers, and growth operators at Digital MUID Academy.",
    ogType: "website",
    schema: {
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": "EducationalOrganization",
          "@id": "https://digitalmuid.in/academy#organization",
          name: "Digital MUID Academy",
          url: "https://digitalmuid.in/academy",
          description: "Explore practical digital marketing, advertising, SEO, and AI education for students, freelancers, and growth operators at Digital MUID Academy.",
          founder: {
            "@type": "Person",
            name: "Digital Muid",
            jobTitle: "Growth Strategist & Systems Architect"
          },
          hasOfferCatalog: {
            "@type": "OfferCatalog",
            name: "Digital MUID Curriculums",
            itemListElement: [
              {
                "@type": "Course",
                name: "Meta Ads Mastery: Algorithmic Scaling & Creative Strategy",
                description: "Build profitable, high-ROAS ad campaigns using algorithmic audience matching and dynamic creative testing.",
                url: "https://digitalmuid.in/learn/meta-ads-mastery",
                offers: {
                  "@type": "Offer",
                  price: "1999",
                  priceCurrency: "INR",
                  availability: "https://schema.org/InStock"
                }
              },
              {
                "@type": "Course",
                name: "SEO (Search Engine Optimisation) with AI Integration",
                description: "Complete SEO mastery course integrating AI search engines, programmatic workflows, and topical authority.",
                url: "https://digitalmuid.in/learn/seo-search-engine-optimisation-with-ai-integration",
                offers: {
                  "@type": "Offer",
                  price: "2499",
                  priceCurrency: "INR",
                  availability: "https://schema.org/InStock"
                }
              },
              {
                "@type": "Course",
                name: "AI & Automation for Modern Business Operations",
                description: "Deploy intelligent LLM agents and automated workflows to cut 15+ hours of manual operations every week.",
                url: "https://digitalmuid.in/learn/ai-automation-business-operations",
                offers: {
                  "@type": "Offer",
                  price: "2199",
                  priceCurrency: "INR",
                  availability: "https://schema.org/InStock"
                }
              }
            ]
          }
        },
        {
          "@type": "WebPage",
          "@id": "https://digitalmuid.in/academy#webpage",
          url: "https://digitalmuid.in/academy",
          name: "Digital MUID Academy | Digital Marketing & AI Education",
          description: "Explore practical digital marketing, advertising, SEO, and AI education for students, freelancers, and growth operators at Digital MUID Academy."
        }
      ]
    },
    semanticHtml: `
      <article>
        <header>
          <h1>Digital MUID Academy: Stop learning platform hacks. Master the mechanics of digital growth.</h1>
          <p>We teach systems, not just buttons. Practical digital marketing, performance advertising, SEO, and AI workflows for high-ticket growth operators.</p>
        </header>
        <section>
          <h2>Educational Philosophy</h2>
          <p>We teach systems, not just buttons. Understand customer intent, CAC/LTV unit economics, attribution telemetry, and autonomous AI agents rather than ephemeral platform tricks.</p>
        </section>
        <section>
          <h2>Featured Curriculums</h2>
          <ul>
            <li><strong>Meta & Google Ads Mastery (\u20B91,999):</strong> Algorithmic media buying, creative testing sandboxes, CAPI telemetry.</li>
            <li><strong>SEO with AI Integration (\u20B92,499):</strong> Topical authority clusters, schema markup, generative AI search workflows.</li>
            <li><strong>AI & Automation for Operations (\u20B92,199):</strong> Autonomous triage agents, webhook synchronization, zero manual friction.</li>
          </ul>
        </section>
        <section>
          <h2>Free Foundation Courses & Toolkits</h2>
          <p>The 60-Minute Digital Marketing Blueprint, Intro to Freelancing & Client Acquisition, AI Prompt Pack, Growth Checklist, and Content Strategy OS.</p>
        </section>
      </article>
    `
  },
  "/learn": {
    path: "/learn",
    canonicalUrl: "https://digitalmuid.in/learn",
    title: "Practical Digital Education & AI Courses | DigitalMUID",
    description: "Practical, AI-integrated digital masterclasses for founders, marketers, and professionals. Real-world systems, actionable frameworks, and live campaigns.",
    ogTitle: "Practical Digital Education & AI Courses | DigitalMUID",
    ogDescription: "Master practical digital marketing, Meta Ads, and AI automation with actionable courses designed to build real business systems.",
    ogType: "website",
    schema: {
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": "EducationalOccupationalProgram",
          "@id": "https://digitalmuid.in/learn#program",
          name: "DigitalMUID Masterclasses & Digital Education",
          description: "Comprehensive, project-based educational curriculum covering Meta Ads Mastery, AI-assisted operations, and modern performance marketing.",
          provider: {
            "@type": "Organization",
            name: "DigitalMUID",
            url: "https://digitalmuid.in/"
          },
          hasCourse: [
            {
              "@type": "Course",
              name: "Meta Ads Mastery: Complete Campaign Architecture",
              description: "End-to-end framework for profitable Meta advertising, audience psychology, creative testing loops, and attribution modeling.",
              url: "https://digitalmuid.in/learn/meta-ads-mastery"
            },
            {
              "@type": "Course",
              name: "AI Automation for Business Operations",
              description: "Practical frameworks for integrating LLMs, workflow automation, and custom agent systems into daily business operations.",
              url: "https://digitalmuid.in/learn/ai-automation-business-operations"
            }
          ]
        },
        {
          "@type": "WebPage",
          "@id": "https://digitalmuid.in/learn#webpage",
          url: "https://digitalmuid.in/learn",
          name: "Practical Digital Education & AI Courses | DigitalMUID",
          description: "Practical, AI-integrated digital masterclasses for founders, marketers, and professionals. Real-world systems, actionable frameworks, and live campaigns."
        }
      ]
    },
    semanticHtml: `
      <article>
        <header>
          <h1>Practical Digital Education & Performance Masterclasses</h1>
          <p>Don't just collect certificates. Build, launch, measure, and scale real digital systems with production-grade templates and live campaign walkthroughs.</p>
        </header>
        <section>
          <h2>Featured Masterclasses & Programs</h2>
          <ul>
            <li>
              <h3>Meta Ads Mastery: Complete Campaign Architecture</h3>
              <p>Comprehensive training on high-performance Meta advertising, audience targeting frameworks, creative fatigue mitigation, and conversion tracking.</p>
              <a href="/learn/meta-ads-mastery">View Meta Ads Mastery Course</a>
            </li>
            <li>
              <h3>AI Automation for Business Operations</h3>
              <p>Practical deployment of generative AI, automated lead flows, operational LLMs, and no-code/low-code integrations.</p>
              <a href="/learn/ai-automation-business-operations">View AI Automation Masterclass</a>
            </li>
          </ul>
        </section>
        <section>
          <h2>Our Learning Standard</h2>
          <p>Every cohort and course provides production-ready assets, verified certificates of completion, and direct actionable insights tested in active client businesses.</p>
          <p><a href="/business-growth-consultation">Need personalized advisory instead? Book a 1-on-1 Consultation</a></p>
        </section>
      </article>
    `
  },
  "/contact": {
    path: "/contact",
    canonicalUrl: "https://digitalmuid.in/contact",
    title: "Contact Digital Muid \u2014 Growth Advisory & Inquiries",
    description: "Get in touch with Digital Muid for growth strategy advisory, web development inquiries, speaking engagements, and collaboration opportunities.",
    ogTitle: "Contact Digital Muid \u2014 Growth Advisory & Inquiries",
    ogDescription: "Connect with Digital Muid for strategic advisory, enterprise web projects, or keynote speaking inquiries.",
    ogType: "website",
    schema: {
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": "ContactPage",
          "@id": "https://digitalmuid.in/contact#webpage",
          url: "https://digitalmuid.in/contact",
          name: "Contact Digital Muid \u2014 Growth Advisory & Inquiries",
          description: "Direct communication channels for consulting, custom website scoping, executive masterclasses, and keynote speaking engagements.",
          mainEntity: {
            "@type": "Person",
            name: "Digital Muid",
            jobTitle: "Growth Strategist & Founder",
            email: "hello@digitalmuid.in",
            url: "https://digitalmuid.in/about"
          }
        }
      ]
    },
    semanticHtml: `
      <article>
        <header>
          <h1>Get in Touch with Digital Muid</h1>
          <p>Have a question regarding strategic growth advisory, custom website development, or corporate education? Let's connect.</p>
        </header>
        <section>
          <h2>Direct Inquiries & Collaboration</h2>
          <p>Whether you represent an established enterprise modernizing legacy workflows or an ambitious founder building what's next, we welcome meaningful discussions.</p>
          <ul>
            <li><strong>Email:</strong> <a href="mailto:hello@digitalmuid.in">hello@digitalmuid.in</a></li>
            <li><strong>Headquarters:</strong> Lucknow, Uttar Pradesh, India (Serving clients globally)</li>
            <li><strong>Inquiry Categories:</strong> Strategic Advisory, Website Development, Keynote Speaking, Custom Corporate Cohorts</li>
          </ul>
        </section>
        <section>
          <h2>Schedule a Dedicated Growth Consultation</h2>
          <p>If you require immediate 1-on-1 strategic focus for your business architecture, reserve a dedicated slot on the calendar.</p>
          <p><a href="/business-growth-consultation">Book a 1-on-1 Consultation</a></p>
        </section>
      </article>
    `
  },
  "/business-growth-consultation": {
    path: "/business-growth-consultation",
    canonicalUrl: "https://digitalmuid.in/business-growth-consultation",
    title: "1-on-1 Business Growth Consultation | DigitalMUID",
    description: "Book a 1-on-1 strategic growth consultation with Digital Muid. Tailored advisory on AI automation, digital transformation, CAC/LTV scaling, and revenue architecture.",
    ogTitle: "1-on-1 Business Growth Consultation | DigitalMUID",
    ogDescription: "Strategic advisory for founders and leaders. Unlock bottlenecks in acquisition, AI workflows, and digital operations.",
    ogType: "website",
    schema: {
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": "Service",
          "@id": "https://digitalmuid.in/business-growth-consultation#service",
          name: "1-on-1 Strategic Business Growth Consultation",
          serviceType: "Executive Strategy & Digital Advisory",
          provider: {
            "@type": "Person",
            name: "Digital Muid",
            jobTitle: "Growth Strategist & AI Transformation Consultant",
            url: "https://digitalmuid.in/about"
          },
          description: "A focused, confidential 1-on-1 strategic deep dive diagnosing growth bottlenecks, customer acquisition economics, AI workflow implementation, and revenue architecture.",
          areaServed: "Worldwide"
        },
        {
          "@type": "WebPage",
          "@id": "https://digitalmuid.in/business-growth-consultation#webpage",
          url: "https://digitalmuid.in/business-growth-consultation",
          name: "1-on-1 Business Growth Consultation | DigitalMUID",
          description: "Book a 1-on-1 strategic growth consultation with Digital Muid. Tailored advisory on AI automation, digital transformation, CAC/LTV scaling, and revenue architecture."
        }
      ]
    },
    semanticHtml: `
      <article>
        <header>
          <h1>1-on-1 Strategic Business Growth Consultation</h1>
          <p>Confidential, high-signal advisory designed to unblock your customer acquisition loops, implement real AI workflows, and scale sustainable revenue.</p>
        </header>
        <section>
          <h2>What We Cover in Your Consultation Session</h2>
          <ul>
            <li><strong>Growth Bottleneck Diagnosis:</strong> Thorough audit of current traffic, conversion friction, and retention gaps across your funnel.</li>
            <li><strong>AI & Automation Architecture:</strong> Practical roadmap for replacing repetitive tasks with automated LLM and agent workflows.</li>
            <li><strong>Acquisition Economics (CAC vs. LTV):</strong> Designing repeatable acquisition channels that scale profitably without burning ad budget.</li>
            <li><strong>Digital Infrastructure & Positioning:</strong> High-authority brand positioning and web presence optimization.</li>
          </ul>
        </section>
        <section>
          <h2>Who This Advisory Is Designed For</h2>
          <p>Startup founders, established business owners, agency principals, and marketing leaders seeking actionable clarity without generic agency fluff.</p>
          <p>Every session includes a post-call action blueprint and recorded video deliverables.</p>
        </section>
        <section>
          <h2>Reserve Your Consultation</h2>
          <p>Select your preferred date and time from the interactive booking calendar, complete secure confirmation, and receive immediate calendar credentials.</p>
          <p><a href="/contact">Have a custom corporate inquiry instead? Contact our team</a></p>
        </section>
      </article>
    `
  },
  "/services": {
    path: "/services",
    canonicalUrl: "https://digitalmuid.in/services",
    title: "Strategic Services & AI Transformation | DigitalMUID",
    description: "Strategic growth services, operational AI automation, modern performance marketing, founder personal branding, and bespoke web development.",
    ogTitle: "Strategic Services & AI Transformation | DigitalMUID",
    ogDescription: "Comprehensive strategic consulting, automation architecture, and digital engineering for scaling companies.",
    ogType: "website",
    schema: {
      "@context": "https://schema.org",
      "@type": "Service",
      name: "DigitalMUID Strategic Consulting & Engineering",
      url: "https://digitalmuid.in/services"
    }
  },
  "/services/growth-systems": {
    path: "/services/growth-systems",
    canonicalUrl: "https://digitalmuid.in/services/growth-systems",
    title: "Growth Systems & Custom Architecture | DigitalMUID",
    description: "Verifiable client acquisition engines, high-velocity React web architecture, and automated qualification funnels engineered for unit economics.",
    ogTitle: "Growth Systems & Custom Architecture | DigitalMUID",
    ogDescription: "Verifiable client acquisition engines, high-velocity React web architecture, and automated qualification funnels engineered for unit economics.",
    ogType: "website",
    schema: {
      "@context": "https://schema.org",
      "@type": "Service",
      name: "DigitalMUID Growth Systems & Custom Architecture",
      url: "https://digitalmuid.in/services/growth-systems"
    }
  },
  "/agency-services": {
    path: "/agency-services",
    canonicalUrl: "https://digitalmuid.in/agency-services",
    title: "Agency Services | Digital MUID",
    description: "Custom web architecture, performance marketing, and AI automation engineered to improve acquisition, lead quality, and operational efficiency.",
    ogTitle: "Agency Services | Digital MUID",
    ogDescription: "Custom web architecture, performance marketing, and AI automation engineered to improve acquisition, lead quality, and operational efficiency.",
    ogType: "website",
    schema: {
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": "ProfessionalService",
          "@id": "https://digitalmuid.in/agency-services#service",
          name: "Digital MUID Enterprise Performance & Custom Development",
          url: "https://digitalmuid.in/agency-services",
          description: "Custom React.js and Node.js web architecture, Meta & Google Ads performance marketing, and CRM AI automation engineered for unit economics.",
          areaServed: "Worldwide",
          provider: {
            "@type": "Person",
            name: "Digital Muid",
            jobTitle: "Growth Strategist & Systems Operator",
            url: "https://digitalmuid.in/about"
          }
        },
        {
          "@type": "WebPage",
          "@id": "https://digitalmuid.in/agency-services#webpage",
          url: "https://digitalmuid.in/agency-services",
          name: "Agency Services | Digital MUID",
          description: "Custom web architecture, performance marketing, and AI automation engineered to improve acquisition, lead quality, and operational efficiency."
        }
      ]
    },
    semanticHtml: `
      <article>
        <header>
          <p>ENTERPRISE PERFORMANCE & CUSTOM DEVELOPMENT</p>
          <h1>We build client acquisition engines, not brochure websites.</h1>
          <p>Stop losing qualified leads to slow loading times and broken funnels. We deploy custom React/Node.js architectures integrated with full-funnel performance marketing to drive predictable B2B and D2C revenue.</p>
        </header>
        <section>
          <h2>The True Cost of a Generic Tech Stack</h2>
          <p>If your landing page takes more than 2.5 seconds to load, your Customer Acquisition Cost (CAC) is artificially high.</p>
        </section>
        <section>
          <h2>Full-Stack Mechanics for Scalable Growth</h2>
          <ul>
            <li><strong>Conversion Web Architecture:</strong> Custom web applications using React.js and Node.js engineered for fast load times and reduced conversion friction.</li>
            <li><strong>Algorithmic Media Buying:</strong> Data-driven campaigns across Meta and Google Ads optimized for pipeline velocity and return on ad spend.</li>
            <li><strong>AI & Operational Automation:</strong> Connecting front-end traffic to back-end sales via intelligent CRM automations and AI lead validation.</li>
          </ul>
        </section>
        <section>
          <h2>The Deployment Phases</h2>
          <ol>
            <li><strong>The Build (Days 1\u201330):</strong> Custom frontend and backend architecture, tracking, and analytics integration. One-time investment.</li>
            <li><strong>The Engine (Ongoing Retainer):</strong> Algorithmic media buying, landing page optimization, and CAC calibration. Monthly partnership.</li>
          </ol>
        </section>
        <section>
          <h2>Ready to audit your infrastructure?</h2>
          <p><a href="/growth-audit">Request a Growth Audit</a></p>
        </section>
      </article>
    `
  },
  "/about": {
    path: "/about",
    canonicalUrl: "https://digitalmuid.in/about",
    title: "About Digital Muid \u2014 Growth Strategist & AI Educator",
    description: "Learn about Digital Muid, background in performance marketing, AI operational frameworks, speaking, and helping brands achieve meaningful scale.",
    ogTitle: "About Digital Muid \u2014 Growth Strategist & AI Educator",
    ogDescription: "Founder, growth strategist, and educator helping modern businesses build lasting digital authority.",
    ogType: "profile",
    schema: {
      "@context": "https://schema.org",
      "@type": "Person",
      name: "Digital Muid",
      url: "https://digitalmuid.in/about"
    }
  },
  "/terms": {
    path: "/terms",
    canonicalUrl: "https://digitalmuid.in/terms",
    title: "Terms & Conditions \u2014 DigitalMUID",
    description: "Terms of service, website use, consultation booking policies, course access conditions, and intellectual property guidelines for DigitalMUID.",
    ogTitle: "Terms & Conditions \u2014 DigitalMUID",
    ogDescription: "Official terms and conditions governing DigitalMUID services, educational courses, and consultations.",
    ogType: "website",
    schema: {
      "@context": "https://schema.org",
      "@type": "WebPage",
      name: "Terms & Conditions \u2014 DigitalMUID",
      url: "https://digitalmuid.in/terms"
    }
  }
};
function getPageSEO(pathname) {
  const clean = (pathname || "/").split("?")[0].split("#")[0].replace(/\/+$/, "") || "/";
  if (SEO_DATA[clean]) {
    return SEO_DATA[clean];
  }
  if (clean === "/consultation") {
    return SEO_DATA["/business-growth-consultation"];
  }
  if (clean === "/courses") {
    return SEO_DATA["/learn"];
  }
  if (clean === "/web-services" || clean === "/web-development" || clean === "/web-design") {
    return SEO_DATA["/web"];
  }
  return null;
}

// server/htmlSeoInjector.js
function injectSeoIntoHtml(html, pathname) {
  const seo = getPageSEO(pathname);
  if (!seo) {
    const cleanPath = (pathname || "/").split("?")[0].split("#")[0].replace(/\/+$/, "") || "/";
    const fallbackCanonical = `${BASE_URL}${cleanPath === "/" ? "/" : cleanPath}`;
    if (!html.includes('rel="canonical"')) {
      html = html.replace("</head>", `  <link rel="canonical" href="${fallbackCanonical}" />
  </head>`);
    }
    return html;
  }
  let modifiedHtml = html;
  if (seo.title) {
    if (modifiedHtml.includes("<title>")) {
      modifiedHtml = modifiedHtml.replace(/<title>[\s\S]*?<\/title>/i, `<title>${seo.title}</title>`);
    } else {
      modifiedHtml = modifiedHtml.replace("</head>", `  <title>${seo.title}</title>
  </head>`);
    }
  }
  if (seo.description) {
    if (modifiedHtml.includes('name="description"')) {
      modifiedHtml = modifiedHtml.replace(
        /<meta\s+name=["']description["']\s+content=["'][\s\S]*?["']\s*\/?>/i,
        `<meta name="description" content="${seo.description.replace(/"/g, "&quot;")}" />`
      );
    } else {
      modifiedHtml = modifiedHtml.replace(
        "</head>",
        `  <meta name="description" content="${seo.description.replace(/"/g, "&quot;")}" />
  </head>`
      );
    }
  }
  const canonicalTag = `<link rel="canonical" href="${seo.canonicalUrl}" />`;
  if (modifiedHtml.includes('rel="canonical"')) {
    modifiedHtml = modifiedHtml.replace(/<link\s+rel=["']canonical["']\s+href=["'][\s\S]*?["']\s*\/?>/i, canonicalTag);
  } else {
    modifiedHtml = modifiedHtml.replace("</head>", `  ${canonicalTag}
  </head>`);
  }
  const ogTitle = `<meta property="og:title" content="${(seo.ogTitle || seo.title).replace(/"/g, "&quot;")}" />`;
  const ogDesc = `<meta property="og:description" content="${(seo.ogDescription || seo.description).replace(/"/g, "&quot;")}" />`;
  const ogUrl = `<meta property="og:url" content="${seo.canonicalUrl}" />`;
  const ogType = `<meta property="og:type" content="${seo.ogType || "website"}" />`;
  if (modifiedHtml.includes('property="og:title"')) {
    modifiedHtml = modifiedHtml.replace(/<meta\s+property=["']og:title["']\s+content=["'][\s\S]*?["']\s*\/?>/i, ogTitle);
  } else {
    modifiedHtml = modifiedHtml.replace("</head>", `  ${ogTitle}
  </head>`);
  }
  if (modifiedHtml.includes('property="og:description"')) {
    modifiedHtml = modifiedHtml.replace(/<meta\s+property=["']og:description["']\s+content=["'][\s\S]*?["']\s*\/?>/i, ogDesc);
  } else {
    modifiedHtml = modifiedHtml.replace("</head>", `  ${ogDesc}
  </head>`);
  }
  if (modifiedHtml.includes('property="og:url"')) {
    modifiedHtml = modifiedHtml.replace(/<meta\s+property=["']og:url["']\s+content=["'][\s\S]*?["']\s*\/?>/i, ogUrl);
  } else {
    modifiedHtml = modifiedHtml.replace("</head>", `  ${ogUrl}
  </head>`);
  }
  if (modifiedHtml.includes('property="og:type"')) {
    modifiedHtml = modifiedHtml.replace(/<meta\s+property=["']og:type["']\s+content=["'][\s\S]*?["']\s*\/?>/i, ogType);
  } else {
    modifiedHtml = modifiedHtml.replace("</head>", `  ${ogType}
  </head>`);
  }
  const twTitle = `<meta name="twitter:title" content="${(seo.ogTitle || seo.title).replace(/"/g, "&quot;")}" />`;
  const twDesc = `<meta name="twitter:description" content="${(seo.ogDescription || seo.description).replace(/"/g, "&quot;")}" />`;
  if (!modifiedHtml.includes('name="twitter:title"')) {
    modifiedHtml = modifiedHtml.replace("</head>", `  ${twTitle}
  ${twDesc}
  </head>`);
  }
  if (seo.schema) {
    const jsonLdTag = `
  <script type="application/ld+json" id="server-seo-jsonld">
${JSON.stringify(seo.schema, null, 2)}
  </script>
`;
    modifiedHtml = modifiedHtml.replace("</head>", `${jsonLdTag}</head>`);
  }
  if (seo.semanticHtml) {
    const semanticWrapper = `<div id="root">
  <div id="ssr-semantic-content" class="sr-crawler-content" style="opacity: 0.99;">
${seo.semanticHtml.trim()}
  </div>
</div>`;
    modifiedHtml = modifiedHtml.replace(/<div\s+id=["']root["']\s*>\s*<\/div>/i, semanticWrapper);
  }
  return modifiedHtml;
}

// server.ts
process.env.DISABLE_HMR = "true";
async function startServer() {
  const app = (0, import_express4.default)();
  const portArgIndex = process.argv.indexOf("--port");
  const cliPort = portArgIndex !== -1 && process.argv[portArgIndex + 1] ? process.argv[portArgIndex + 1] : null;
  const isDevContainer = Boolean(
    process.env.NGINX_PORT || process.env.DEFAULT_APP_PORT || process.env.CONTROL_PLANE_PORT || process.env.K_SERVICE?.startsWith("ais-dev-")
  );
  const isProduction = process.env.NODE_ENV === "production" || !isDevContainer;
  const PORT = process.env.TEST_PORT ? parseInt(process.env.TEST_PORT, 10) : isDevContainer && process.env.NODE_ENV !== "production" ? parseInt(cliPort || "3000", 10) : parseInt(process.env.PORT || cliPort || "8080", 10);
  app.post(
    "/api/payments/webhook",
    import_express4.default.raw({ type: "*/*" }),
    handleRazorpayWebhook
  );
  app.use(
    import_express4.default.json({
      verify: (req, _res, buf) => {
        if (buf && buf.length) {
          req.rawBody = buf;
        }
      }
    })
  );
  app.use(import_express4.default.urlencoded({ extended: true }));
  app.get(["/healthz", "/health", "/api/health"], (_req, res) => {
    res.json({
      status: "ok",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      gateway: {
        razorpayConfigured: isRazorpayConfigured(),
        webhookConfigured: isWebhookConfigured(),
        supabaseServerConfigured: isSupabaseServerConfigured()
      }
    });
  });
  app.use("/api/payments", paymentRoutes_default);
  app.use("/api/web-enquiries", webEnquiryRoutes_default);
  app.use("/api/growth-audit", growthAuditRoutes_default);
  app.all("/api/*", (_req, res) => {
    res.status(404).json({ error: "API endpoint not found" });
  });
  app.use(seoRedirectMiddleware);
  if (!isProduction) {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true, hmr: false },
      appType: "custom"
    });
    app.use(vite.middlewares);
    app.use((req, res, next) => {
      if (req.path.endsWith(".xml") && req.path !== "/sitemap.xml") {
        res.status(404);
        res.setHeader("Content-Type", "application/xml; charset=utf-8");
        return res.send(`<?xml version="1.0" encoding="UTF-8"?><error><status>404</status><message>XML resource not found</message></error>`);
      }
      next();
    });
    app.get("*", async (req, res, next) => {
      if (req.path.startsWith("/api") || req.path.includes(".")) {
        return next();
      }
      try {
        const templatePath = import_path.default.resolve(process.cwd(), "index.html");
        let template = import_fs.default.readFileSync(templatePath, "utf-8");
        template = await vite.transformIndexHtml(req.originalUrl || req.url, template);
        const finalHtml = injectSeoIntoHtml(template, req.path);
        res.status(200).set({ "Content-Type": "text/html; charset=utf-8" }).end(finalHtml);
      } catch (e) {
        next(e);
      }
    });
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    const indexPath = import_path.default.join(distPath, "index.html");
    app.use(import_express4.default.static(distPath, { index: false, redirect: false }));
    app.use((req, res, next) => {
      if (req.path.endsWith(".xml")) {
        res.status(404);
        res.setHeader("Content-Type", "application/xml; charset=utf-8");
        return res.send(`<?xml version="1.0" encoding="UTF-8"?><error><status>404</status><message>XML resource not found</message></error>`);
      }
      next();
    });
    app.get("*", (req, res) => {
      try {
        if (!import_fs.default.existsSync(indexPath)) {
          res.setHeader("Content-Type", "text/html; charset=utf-8");
          return res.status(200).send("<!doctype html><html><head><title>Loading...</title></head><body>Application is starting up...</body></html>");
        }
        const cleanSubdir = req.path.replace(/^\/+/, "").replace(/\/+$/, "");
        const specificHtmlPath = cleanSubdir ? import_path.default.join(distPath, cleanSubdir, "index.html") : indexPath;
        let html = import_fs.default.existsSync(specificHtmlPath) ? import_fs.default.readFileSync(specificHtmlPath, "utf8") : import_fs.default.readFileSync(indexPath, "utf8");
        html = injectSeoIntoHtml(html, req.path);
        const clientEnv = {
          VITE_SUPABASE_URL: process.env.VITE_SUPABASE_URL || "",
          VITE_SUPABASE_ANON_KEY: process.env.VITE_SUPABASE_ANON_KEY || "",
          VITE_RAZORPAY_KEY_ID: process.env.VITE_RAZORPAY_KEY_ID || ""
        };
        const serializedEnv = JSON.stringify(clientEnv).replace(/</g, "\\u003c");
        const envScript = `<script>window.__ENV__ = Object.assign(window.__ENV__ || {}, ${serializedEnv});</script>`;
        if (html.includes("</head>")) {
          html = html.replace("</head>", `${envScript}</head>`);
        } else {
          html = envScript + html;
        }
        res.setHeader("Content-Type", "text/html; charset=utf-8");
        res.send(html);
      } catch (_err) {
        if (import_fs.default.existsSync(indexPath)) {
          res.sendFile(indexPath);
        } else {
          res.status(200).send("<!doctype html><html><head><title>Loading...</title></head><body>Application is starting up...</body></html>");
        }
      }
    });
  }
  const server = app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT} (mode: ${isProduction ? "production" : "development"})`);
    if (isRazorpayConfigured()) {
      console.log("[Payment Gateway] Razorpay server credentials detected.");
    } else {
      console.log("[Payment Gateway] Razorpay server credentials not configured (development mode).");
    }
  });
  server.on("error", (err) => {
    console.error("[Server Error]", err);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
