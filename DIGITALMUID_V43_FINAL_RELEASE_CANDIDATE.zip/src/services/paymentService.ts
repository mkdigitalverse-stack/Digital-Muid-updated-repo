import { supabase, isSupabaseConfigured } from '../lib/supabase';
import {
  PaymentRecord,
  CreateCourseOrderResult,
  VerifyCoursePaymentResult,
  CreateConsultationOrderResult,
  VerifyConsultationPaymentResult,
  CreateResourceOrderResult,
  VerifyResourcePaymentResult,
  RecoverLeadResult
} from '../types';

import { formatStudentId, formatInvoiceNumber } from '../utils/studentId';
import { InvoiceModel, CreditNoteModel } from '../types';

/**
 * Transforms a raw row from public.payments into a domain PaymentRecord object.
 */
export const mapDbRowToPaymentRecord = (row: any): PaymentRecord => ({
  id: row.id,
  userId: row.user_id,
  studentId: formatStudentId(row.user_id, row.student_id),
  invoiceNumber: formatInvoiceNumber(row.created_at, row.razorpay_payment_id || row.id, row.invoice_number),
  itemType: (row.item_type as 'course' | 'consultation' | 'subscription' | 'resource') || 'course',
  itemId: row.item_id || null,
  itemTitle: row.item_title || 'Digital Muid Educational Service',
  amount: typeof row.amount === 'number' ? row.amount : parseFloat(row.amount || '0') || 0,
  currency: row.currency || 'INR',
  razorpayOrderId: row.razorpay_order_id || null,
  razorpayPaymentId: row.razorpay_payment_id || null,
  status: (row.status as 'pending' | 'captured' | 'failed' | 'refunded') || 'captured',
  invoiceUrl: row.invoice_url || null,
  createdAt: row.created_at
});

export const paymentService = {
  /**
   * Fetches payment records for the currently authenticated student.
   * Strictly enforces client-side authentication and queries public.payments
   * filtered by user_id under Supabase Row-Level Security.
   */
  async fetchMyPayments(): Promise<{ data: PaymentRecord[]; error: any }> {
    try {
      if (!isSupabaseConfigured()) {
        return { data: [], error: null };
      }

      // 1. Obtain current authenticated student session
      const { data: { user }, error: authError } = await supabase.auth.getUser();
      if (authError || !user) {
        return { data: [], error: authError || new Error('User is not authenticated') };
      }

      // 2. Fetch payment transactions for this student only, ordered chronologically
      const { data, error } = await supabase
        .from('payments')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('[PaymentService] Error querying payments from Supabase:', error);
        return { data: [], error };
      }

      if (!data || data.length === 0) {
        return { data: [], error: null };
      }

      const domainPayments = data.map(mapDbRowToPaymentRecord);
      return { data: domainPayments, error: null };
    } catch (err: any) {
      console.error('[PaymentService] Unexpected exception fetching payments:', err);
      return { data: [], error: err };
    }
  },

  /**
   * Fetches all payments across the platform for authenticated CRM/Admin users.
   * Calls secure server API /api/payments/admin/all-payments with fallback to Supabase query.
   */
  async fetchAllPaymentsForAdmin(): Promise<{ data: PaymentRecord[]; error: any }> {
    try {
      if (isSupabaseConfigured()) {
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.access_token) {
          try {
            const res = await fetch('/api/payments/admin/all-payments', {
              headers: {
                Authorization: `Bearer ${session.access_token}`
              }
            });
            if (res.ok) {
              const json = await res.json();
              if (json.success && Array.isArray(json.payments)) {
                return { data: json.payments.map(mapDbRowToPaymentRecord), error: null };
              }
            }
          } catch (apiErr) {
            console.warn('[PaymentService] Server admin payments endpoint notice:', apiErr);
          }
        }

        // Direct fallback query under admin RLS
        const { data, error } = await supabase
          .from('payments')
          .select('*')
          .order('created_at', { ascending: false });

        if (!error && data) {
          return { data: data.map(mapDbRowToPaymentRecord), error: null };
        }
      }

      return { data: [], error: null };
    } catch (err: any) {
      console.error('[PaymentService] Error fetching all payments for admin:', err);
      return { data: [], error: err };
    }
  },

  /**
   * Fetches authoritative invoice details as JSON for interactive modal display.
   */
  async fetchInvoiceDetails(paymentId: string): Promise<{
    data: InvoiceModel | null;
    creditNote?: CreditNoteModel | null;
    isCreditNote?: boolean;
    error: any;
  }> {
    try {
      if (!isSupabaseConfigured()) {
        return { data: null, error: new Error('Database service is not configured.') };
      }

      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        return { data: null, error: new Error('Authentication required to view tax invoice.') };
      }

      const res = await fetch(`/api/payments/invoice/${encodeURIComponent(paymentId)}?format=json`, {
        headers: {
          Authorization: `Bearer ${session.access_token}`
        }
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        return { data: null, error: new Error(errJson.error || 'Failed to retrieve invoice data.') };
      }

      const json = await res.json();
      if (json.success) {
        if (json.isCreditNote && json.creditNote) {
          return { data: null, creditNote: json.creditNote as CreditNoteModel, isCreditNote: true, error: null };
        }
        if (json.invoice) {
          return { data: json.invoice as InvoiceModel, error: null };
        }
      }

      return { data: null, error: new Error('Invoice data format unrecognized.') };
    } catch (err: any) {
      console.error('[PaymentService] Error fetching invoice details:', err);
      return { data: null, error: err };
    }
  },

  /**
   * Downloads the authoritative PDF tax invoice from the server.
   */
  async downloadOfficialInvoice(paymentId: string, invoiceNumber?: string): Promise<{ success: boolean; error?: string }> {
    try {
      if (!isSupabaseConfigured()) {
        return { success: false, error: 'Database service is not configured.' };
      }

      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        return { success: false, error: 'Authentication required to download tax invoice.' };
      }

      const res = await fetch(`/api/payments/invoice/${encodeURIComponent(paymentId)}`, {
        headers: {
          Authorization: `Bearer ${session.access_token}`
        }
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        return { success: false, error: errJson.error || 'Failed to download official tax invoice.' };
      }

      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      const safeNum = (invoiceNumber || `DM-INV-${paymentId.slice(-4)}`).replace(/[/\\?%*:|"<>]/g, '_');
      link.download = `DigitalMuid-Invoice-${safeNum}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => URL.revokeObjectURL(url), 4000);

      return { success: true };
    } catch (err: any) {
      console.error('[PaymentService] Error downloading invoice PDF:', err);
      return { success: false, error: err?.message || 'Network error downloading tax invoice.' };
    }
  },

  /**
   * Downloads the authoritative PDF credit note from the server.
   */
  async downloadOfficialCreditNote(paymentId: string, creditNoteNumber?: string): Promise<{ success: boolean; error?: string }> {
    try {
      if (!isSupabaseConfigured()) {
        return { success: false, error: 'Database service is not configured.' };
      }

      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        return { success: false, error: 'Authentication required to download credit note.' };
      }

      const res = await fetch(`/api/payments/invoice/${encodeURIComponent(paymentId)}?type=credit-note`, {
        headers: {
          Authorization: `Bearer ${session.access_token}`
        }
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        return { success: false, error: errJson.error || 'Failed to download credit note.' };
      }

      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      const safeNum = (creditNoteNumber || `CN-REF-${paymentId.slice(-4)}`).replace(/[/\\?%*:|"<>]/g, '_');
      link.download = `DigitalMuid-CreditNote-${safeNum}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => URL.revokeObjectURL(url), 4000);

      return { success: true };
    } catch (err: any) {
      console.error('[PaymentService] Error downloading credit note PDF:', err);
      return { success: false, error: err?.message || 'Network error downloading credit note.' };
    }
  },

  async createCourseOrder(courseId: string): Promise<CreateCourseOrderResult> {
    try {
      if (!isSupabaseConfigured()) {
        return {
          success: false,
          error: 'Authentication service is not configured.'
        };
      }

      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      if (sessionError || !session?.access_token) {
        return {
          success: false,
          error: 'You must be signed in to enroll in this course.'
        };
      }

      const response = await fetch('/api/payments/create-course-order', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${session.access_token}`
        },
        body: JSON.stringify({ courseId })
      });

      const result: CreateCourseOrderResult = await response.json();
      return result;
    } catch (err: any) {
      console.error('[PaymentService] Error invoking create-course-order API:', err);
      return {
        success: false,
        error: err?.message || 'Failed to connect to order creation service.'
      };
    }
  },

  /**
   * Cryptographically verifies a completed Razorpay Checkout transaction on the server.
   * Transmits ONLY order/payment identifiers, signature, and courseId with the student's JWT.
   * Server determines cryptographic authenticity using RAZORPAY_KEY_SECRET (Phase 2K-D).
   */
  async verifyCoursePayment(params: {
    razorpay_order_id: string;
    razorpay_payment_id: string;
    razorpay_signature: string;
    courseId: string;
  }): Promise<VerifyCoursePaymentResult> {
    try {
      if (!isSupabaseConfigured()) {
        return {
          success: false,
          verified: false,
          error: 'Authentication service is not configured.'
        };
      }

      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      if (sessionError || !session?.access_token) {
        return {
          success: false,
          verified: false,
          error: 'You must be signed in to verify payment.'
        };
      }

      const response = await fetch('/api/payments/verify-course-payment', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${session.access_token}`
        },
        body: JSON.stringify(params)
      });

      const result: VerifyCoursePaymentResult = await response.json();
      return result;
    } catch (err: any) {
      console.error('[PaymentService] Error verifying course payment:', err);
      return {
        success: false,
        verified: false,
        error: err?.message || 'Network error while verifying payment with server.'
      };
    }
  },

  /**
   * Requests server-side Razorpay order creation for a consultation booking.
   * Price is read strictly server-side from public.consultation_products.
   */
  async createConsultationOrder(bookingDetails: {
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    businessName: string;
    primaryChallenge: string;
    desiredOutcome: string;
    website?: string;
    linkedin?: string;
    date: string;
    time: string;
  }): Promise<CreateConsultationOrderResult> {
    try {
      const headers: Record<string, string> = {
        'Content-Type': 'application/json'
      };

      if (isSupabaseConfigured()) {
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.access_token) {
          headers.Authorization = `Bearer ${session.access_token}`;
        }
      }

      const response = await fetch('/api/payments/create-consultation-order', {
        method: 'POST',
        headers,
        body: JSON.stringify({ bookingDetails })
      });

      const result: CreateConsultationOrderResult = await response.json();
      return result;
    } catch (err: any) {
      console.error('[PaymentService] Error creating consultation order:', err);
      return {
        success: false,
        error: err?.message || 'Failed to connect to consultation order service.'
      };
    }
  },

  /**
   * Cryptographically verifies a completed Razorpay payment for a consultation booking.
   * Fulfills booking in public.bookings and records payment in public.payments.
   */
  async verifyConsultationPayment(params: {
    razorpay_order_id: string;
    razorpay_payment_id: string;
    razorpay_signature: string;
    bookingDetails: any;
  }): Promise<VerifyConsultationPaymentResult> {
    try {
      const headers: Record<string, string> = {
        'Content-Type': 'application/json'
      };

      if (isSupabaseConfigured()) {
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.access_token) {
          headers.Authorization = `Bearer ${session.access_token}`;
        }
      }

      const response = await fetch('/api/payments/verify-consultation-payment', {
        method: 'POST',
        headers,
        body: JSON.stringify(params)
      });

      const result: VerifyConsultationPaymentResult = await response.json();
      return result;
    } catch (err: any) {
      console.error('[PaymentService] Error verifying consultation payment:', err);
      return {
        success: false,
        verified: false,
        error: err?.message || 'Network error while verifying consultation payment with server.'
      };
    }
  },

  /**
   * Requests server-side Razorpay order creation for a paid digital resource.
   * Price is read strictly server-side from public.resources (authoritative).
   */
  async createResourceOrder(
    resourceId: string,
    customerDetails?: {
      name?: string;
      email?: string;
      phone?: string;
    },
    pricingHint?: {
      accessType?: string;
      price?: number;
    }
  ): Promise<CreateResourceOrderResult> {
    try {
      const headers: Record<string, string> = {
        'Content-Type': 'application/json'
      };

      if (isSupabaseConfigured()) {
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.access_token) {
          headers.Authorization = `Bearer ${session.access_token}`;
        }
      }

      const response = await fetch('/api/payments/create-resource-order', {
        method: 'POST',
        headers,
        body: JSON.stringify({ resourceId, customerDetails, ...pricingHint })
      });

      const result: CreateResourceOrderResult = await response.json();
      return result;
    } catch (err: any) {
      console.error('[PaymentService] Error creating resource order:', err);
      return {
        success: false,
        error: err?.message || 'Failed to connect to resource order service.'
      };
    }
  },

  /**
   * Cryptographically verifies a completed Razorpay payment for a paid resource.
   * Records purchase in public.resource_purchases and payment in public.payments.
   */
  async verifyResourcePayment(params: {
    razorpay_order_id: string;
    razorpay_payment_id: string;
    razorpay_signature: string;
    resourceId: string;
    customerDetails?: any;
  }): Promise<VerifyResourcePaymentResult> {
    try {
      const headers: Record<string, string> = {
        'Content-Type': 'application/json'
      };

      if (isSupabaseConfigured()) {
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.access_token) {
          headers.Authorization = `Bearer ${session.access_token}`;
        }
      }

      const response = await fetch('/api/payments/verify-resource-payment', {
        method: 'POST',
        headers,
        body: JSON.stringify(params)
      });

      const result: VerifyResourcePaymentResult = await response.json();
      if (result.success && result.verified && result.resourceAccessToken) {
        saveStoredGuestResourceToken({
          resourceId: (result as any).resourceId || params.resourceId,
          orderId: result.orderId || params.razorpay_order_id,
          paymentId: result.paymentId || params.razorpay_payment_id,
          token: result.resourceAccessToken
        });
      }
      return result;
    } catch (err: any) {
      console.error('[PaymentService] Error verifying resource payment:', err);
      return {
        success: false,
        verified: false,
        error: err?.message || 'Network error while verifying resource payment with server.'
      };
    }
  },

  /**
   * Safe idempotent CRM lead recovery after a verified payment.
   * Does NOT charge or re-verify payment; only synchronizes missing CRM lead row.
   */
  async recoverLead(params: {
    orderId: string;
    paymentId: string;
    resourceId: string;
    resourceAccessToken?: string;
    customerDetails?: {
      name?: string;
      email?: string;
      phone?: string;
      profession?: string;
    };
  }): Promise<RecoverLeadResult> {
    try {
      const resolvedGuestToken =
        params.resourceAccessToken ||
        getStoredGuestResourceToken(params.resourceId, params.orderId, params.paymentId);

      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        ...(resolvedGuestToken ? { 'x-resource-access-token': resolvedGuestToken } : {})
      };

      if (isSupabaseConfigured()) {
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.access_token) {
          headers.Authorization = `Bearer ${session.access_token}`;
        }
      }

      const response = await fetch('/api/payments/recover-lead', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          ...params,
          ...(resolvedGuestToken ? { resourceAccessToken: resolvedGuestToken } : {})
        })
      });

      const result: RecoverLeadResult = await response.json();
      return result;
    } catch (err: any) {
      console.warn('[PaymentService] Notice recovering lead with server:', err);
      return {
        success: false,
        payment_verified: true,
        lead_status: 'failed',
        error: err?.message || 'Network error while recovering CRM lead.'
      };
    }
  }
};

const BUNDLE_CANONICAL_ID = '2d50e5e3-711d-4461-a70d-0ed54dd29f17';
const BUNDLE_CANONICAL_SLUG = 'meta-ads-campaign-planner-bundle';
const GUEST_TOKEN_STORAGE_PREFIX = 'dm_guest_res_tok_';
const GUEST_TX_TOKEN_STORAGE_PREFIX = 'dm_guest_res_tx_';
const MEMORY_GUEST_TOKEN_TTL_MS = 30 * 60 * 1000; // 30 min max same-session fallback when sessionStorage fails

interface MemoryTokenEntry {
  token: string;
  expiresAt: number;
}

const memoryGuestTokenStore = new Map<string, MemoryTokenEntry>();
const cleanupRegisteredWindows = new WeakSet<object>();

export function clearMemoryGuestResourceTokens(): void {
  memoryGuestTokenStore.clear();
}

function getSafeSessionStorage(): Storage | null {
  try {
    if (typeof window === 'undefined') return null;
    const storage = window.sessionStorage;
    if (!storage || typeof storage.getItem !== 'function' || typeof storage.setItem !== 'function') {
      return null;
    }
    return storage;
  } catch {
    return null;
  }
}

function registerMemoryCleanup(): void {
  if (typeof window === 'undefined') return;
  try {
    if (cleanupRegisteredWindows.has(window)) return;
    cleanupRegisteredWindows.add(window);
    const wipe = () => {
      memoryGuestTokenStore.clear();
    };
    window.addEventListener?.('pagehide', wipe);
    window.addEventListener?.('beforeunload', wipe);
  } catch {
    // Fail safely in restricted environments
  }
}

function pruneExpiredMemoryTokens(now = Date.now()): void {
  for (const [key, entry] of memoryGuestTokenStore.entries()) {
    if (!entry || entry.expiresAt <= now) {
      memoryGuestTokenStore.delete(key);
    }
  }
}

export function saveStoredGuestResourceToken(params: {
  resourceId?: string | null;
  orderId?: string | null;
  paymentId?: string | null;
  token?: string | null;
}): boolean {
  const token = String(params.token || '').trim();
  const orderId = String(params.orderId || '').trim();
  const paymentId = String(params.paymentId || '').trim();
  const resourceId = String(params.resourceId || '').trim();
  if (!token || !orderId || !paymentId) return false;

  const keys: string[] = [`${GUEST_TX_TOKEN_STORAGE_PREFIX}${orderId}_${paymentId}`];
  if (resourceId) {
    keys.push(`${GUEST_TOKEN_STORAGE_PREFIX}${resourceId}_${orderId}_${paymentId}`);
    if (resourceId === BUNDLE_CANONICAL_ID || resourceId === BUNDLE_CANONICAL_SLUG) {
      keys.push(`${GUEST_TOKEN_STORAGE_PREFIX}${BUNDLE_CANONICAL_ID}_${orderId}_${paymentId}`);
      keys.push(`${GUEST_TOKEN_STORAGE_PREFIX}${BUNDLE_CANONICAL_SLUG}_${orderId}_${paymentId}`);
    }
  }

  let persisted = false;
  const storage = getSafeSessionStorage();
  if (storage) {
    try {
      for (const k of keys) {
        storage.setItem(k, token);
      }
      persisted = storage.getItem(`${GUEST_TX_TOKEN_STORAGE_PREFIX}${orderId}_${paymentId}`) === token;
    } catch {
      persisted = false;
    }
  }

  // Retain in memory ONLY if sessionStorage failed (current page session only, never reload recovery)
  if (!persisted) {
    registerMemoryCleanup();
    pruneExpiredMemoryTokens();
    const expiresAt = Date.now() + MEMORY_GUEST_TOKEN_TTL_MS;
    for (const k of keys) {
      memoryGuestTokenStore.set(k, { token, expiresAt });
    }
  }

  return persisted;
}

export function getStoredGuestResourceToken(
  resourceId?: string | null,
  orderId?: string | null,
  paymentId?: string | null
): string | null {
  const cleanOrderId = String(orderId || '').trim();
  const cleanPaymentId = String(paymentId || '').trim();
  const cleanResourceId = String(resourceId || '').trim();
  if (!cleanOrderId || !cleanPaymentId) return null;

  const candidateKeys: string[] = [];
  if (cleanResourceId) {
    candidateKeys.push(`${GUEST_TOKEN_STORAGE_PREFIX}${cleanResourceId}_${cleanOrderId}_${cleanPaymentId}`);
    if (cleanResourceId === BUNDLE_CANONICAL_ID || cleanResourceId === BUNDLE_CANONICAL_SLUG) {
      const aliasKey = cleanResourceId === BUNDLE_CANONICAL_ID ? BUNDLE_CANONICAL_SLUG : BUNDLE_CANONICAL_ID;
      candidateKeys.push(`${GUEST_TOKEN_STORAGE_PREFIX}${aliasKey}_${cleanOrderId}_${cleanPaymentId}`);
    }
  }
  candidateKeys.push(`${GUEST_TX_TOKEN_STORAGE_PREFIX}${cleanOrderId}_${cleanPaymentId}`);

  if (typeof window !== 'undefined') {
    const storage = getSafeSessionStorage();
    if (storage) {
      try {
        for (const k of candidateKeys) {
          const val = storage.getItem(k);
          if (val) return val;
        }
      } catch {
        // Fall back to bounded current-session memory store below
      }
    }

    try {
      const consumeBootstrap = (window as any).__dmConsumeBootstrapGuestToken;
      if (typeof consumeBootstrap === 'function') {
        const bootstrapToken = consumeBootstrap(cleanOrderId, cleanPaymentId);
        if (bootstrapToken) {
          registerMemoryCleanup();
          pruneExpiredMemoryTokens();
          const expiresAt = Date.now() + MEMORY_GUEST_TOKEN_TTL_MS;
          for (const k of candidateKeys) {
            memoryGuestTokenStore.set(k, { token: bootstrapToken, expiresAt });
          }
          return bootstrapToken;
        }
      }
    } catch {
      // Ignore restricted window access
    }
  }

  pruneExpiredMemoryTokens();
  for (const k of candidateKeys) {
    const entry = memoryGuestTokenStore.get(k);
    if (entry && entry.expiresAt > Date.now()) {
      return entry.token;
    }
  }

  return null;
}

